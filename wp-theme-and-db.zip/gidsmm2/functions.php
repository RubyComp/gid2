<?php

require_once('actions/cleanup-wp.php');
require_once('actions/theme-prepare.php');
require_once('actions/shortcodes.php');
require_once('actions/balance.php');
require_once('actions/users-table-extend.php');
require_once('actions/orders-table.php');
require_once('actions/deposits-table.php');
require_once('actions/services-table.php');
require_once('actions/outs-table.php');

require_once ('parts/payments/callback/callback_onepayments.php');
require_once ('parts/payments/callback/callback_lava.php');

require_once ('parts/payments/methods/log/telegramLog.php');
require_once ('parts/payments/methods/onepayments.php');
require_once ('parts/payments/methods/lava.php');
require_once ('modules/bonuses.php');
require_once ('modules/deposit-funds.php');
require_once ('modules/Api.php');

add_action('wp_enqueue_scripts', 'enqueue_ajax_script');
function enqueue_ajax_script() {
	wp_enqueue_script('ajax-script', get_template_directory_uri() . '/ajax-script.js', array('jquery'), '1.0', true);
	wp_localize_script('ajax-script', 'ajax_object', array('ajax_url' => admin_url('admin-ajax.php')));
}

add_action('wp_ajax_update_service_rate_ratio', 'update_service_rate_ratio');
add_action('wp_ajax_nopriv_update_service_rate_ratio', 'update_service_rate_ratio');

function update_service_rate_ratio() {
	if (isset($_POST['service_rate_ratio'])) {
		$new_value = sanitize_text_field($_POST['service_rate_ratio']);
		update_option('service_rate_ratio', $new_value);
		echo 'Success';
	}
	wp_die();
}


function custom_page_columns($columns) {
	$columns['page_permalink'] = 'Постоянная ссылка';
	return $columns;
}
add_filter('manage_pages_columns', 'custom_page_columns');

function custom_page_column_content($column_name, $post_id) {
	if ($column_name === 'page_permalink') {
		$page_permalink = get_permalink($post_id);
		$home_url = get_home_url();
		$page_permalink = str_replace($home_url, '', $page_permalink);
		$page_permalink = untrailingslashit($page_permalink);
		echo esc_html($page_permalink);
	}
}
add_action('manage_pages_custom_column', 'custom_page_column_content', 10, 2);
