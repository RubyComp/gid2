<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	$user_data = array(
		// 'user_login'    => $_POST['username'],
		'user_email'    => $_POST['email'],
		'user_pass'     => $_POST['password'],
		// Добавьте другие поля по вашему усмотрению
	);

	$user_id = wp_insert_user($user_data);

	if (!is_wp_error($user_id)) {
		// Пользователь успешно зарегистрирован
	} else {
		// Обработка ошибок
	}
}

?>

<section class="fluid-container">
	<div class="back">
		<div class="welcome-form">
			<?php
				do_shortcode('[ultimatemember form_id="6"]');
			?>
			<!-- <div class="welcome-form__main">
				<h1 class="welcome-form__title">Создать аккаунт</h1>
				<fieldset class="welcome-form__fieldset">
					<input class="input welcome-form__input-text" type="text" placeholder="E-mail">
					<input class="input welcome-form__input-text" type="text" placeholder="Пароль">
				</fieldset>
				<div class="welcome-form__note">Я соглашаюсь, что ознакомлен с <a class="link" href="/legal.html">политикой&nbsp;конфеденциальности</a></div>
				<div><a class="btn btn_extra btn_primary" href="">Создать аккаунт</a></div>
			</div> -->
			<footer class="welcome-form__footer">
				<div>Есть аккаунт? <a href="/login.html">Войти</a></div>
			</footer>
		</div>
	</div>
</section>