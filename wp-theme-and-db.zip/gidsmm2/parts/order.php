<?php
include(__DIR__ . '/../modules/users-only.php');

require_once(__DIR__ . '/../modules/deposit-funds.php');
require_once(__DIR__ . '/../modules/Api.php');

require_once (__DIR__ . '/payments/methods/onepayments.php');
require_once (__DIR__ . '/payments/methods/cardlink.php');
require_once (__DIR__ . '/payments/methods/lava.php');

if (!isset($_REQUEST["id"])) {
	header("Location: /catalog/");
	die();
}

global $wpdb;
$service = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . $wpdb->prefix . "services_methods WHERE id = %d", $_REQUEST["id"]));

$alert = "";
$alertColor = "#af2f80";


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$userId = wp_get_current_user()->ID;

	$cost = round($service->rate * $_REQUEST["count"], 2);
	$balance = get_current_user_balance();

	if (isset($_REQUEST["mode"])  && $_REQUEST["mode"] == 'pre-order') {

		// echo '<pre>';
		// print_r($_REQUEST);
		// echo '</pre>';

		global $wpdb;

		$table_name = $wpdb->prefix . 'pre_orders';

		$method_id = intval($_POST['method_id']);
		$url = sanitize_text_field($_POST['url']);
		$count = intval($_REQUEST["count"]);

		if (empty($method_id) || empty($url) || empty($count)) {
			$alert = "Не все поля заполнены!";
			$alertColor = "red";
		} else {
			$data = array(
				'user_id' => $userId,
				'method_id' => $method_id,
				'url' => $url,
				'count' => $count
			);

			$format = array(
				'%d',
				'%d',
				'%s',
				'%d'
			);

			$wpdb->insert($table_name, $data, $format);

			if ($wpdb->insert_id) {
				$pre_order = $wpdb->insert_id;

				switch ($_POST["payment"] ?? "non") {
					case "onepayments":
						$payment = new onepayments();
						break;
					case "lava":
						$payment = new lava();
						break;
					default:
						echo 'Данный метод платежа недоступен';
						return;
				}
				// echo 'process';
				$process = $payment->process($cost, wp_get_current_user()->ID, $pre_order);
				$pay_url = $process["url"];
			} else {
				echo 'Произошла ошибка при добавлении записи.';
			}
		}


	} else if ($cost > $balance) {
		$alert = "На вашем балансе недостаточно средств!";
	} else {
		$api = new Api();
		$order = $api->order([
			'service' => $service->apiId,
			'link' => $_REQUEST["url"],
			'quantity' => $_REQUEST["count"]
		]);
		//$order = new stdClass();
		//$order->order = 11;

		if (!$order) $alert = "Произошла ошибка!";
		else {
			undeposit_funds($userId, $cost);

			$wpdb->insert($wpdb->prefix . "service_orders", [
				'user_id' => $userId,
				'serviceId' => $service->serviceId,
				'apiId' => $service->apiId,
				'orderId' => $order->order,
				"cost" => $cost,
				"count" => $_REQUEST["count"],
				"url" => $_REQUEST["url"],
				"name" => $service->name,
				"date" => date("d.m.Y H:i:s")
			]);

			$alert = "Заказ оформлен! <a href='/dashboard/'>Личный кабинет</a>";
			$alertColor = "green";

			echo "<script>setTimeout(function() {window.location.href='/orders/';}, 1000);</script>";
		}
	}
}

?>
<div class="container">

	<?php if (isset($pay_url) && $pay_url): ?>

		<div class="block">
			<?php get_pay_redirect_html($pay_url) ?>
		</div>

	<?php else: ?>

		<div class="account">

			<?php require(__DIR__ . '/../modules/account-aside.php'); ?>

			<div class="account__main">
				<div class="account__block">

					<div class="bread">Заказ услуги</div>
					<h1 class="account__title">Оформление заказа</h1>
					<div class="alert">
						<label class="label" style="color: <?php echo $alertColor; ?>"><?php echo $alert; ?></label>
					</div>
					<?php if ($alertColor !== "green"): ?>
						<form class="form" method="POST" id="orderForm">
							<div><?php echo $service->name; ?></div>
							<section class="input-section">
								<div class="input-title">Ссылка на страницу</div>
								<div class="extra-input">
									<input
										type="text"
										id="url"
										name="url"
										placeholder="Введите url"
										required
									>
								</div>
							</section>
							<section class="input-section">
								<div class="input-title">Ссылка на страницу</div>
								<div class="extra-input">
									<input
										id="count"
										name="count"
										type="number"
										step="1"
										min="<?php echo $service->min; ?>"
										max="<?php echo $service->max; ?>"
										placeholder="Введите число"
										required
									>
								</div>
							</section>
							<!-- <div>
								<label for="fieldName" class="label">Ссылка на страницу</label>
								<input class="field" id="url" name="url" placeholder="Введите url" required>
							</div> -->
							<!-- <br>
							<div>
								<label for="fieldName" class="label">Количество накруток</label>
								<input
									class="field"
									id="count"
									name="count"
									type="number"
									step="1"
									min="<?php echo $service->min; ?>"
									max="<?php echo $service->max; ?>"
									placeholder="Введите число"
									required
								>
							</div> -->
							<div>К оплате: <span id="order-price">…</span> руб.</small></div>
							<div class="form-actions">
								<button class="btn btn_primary" type="submit">
									<span>Оплатить</span>
								</button>
							</div>
						</form>
					<?php endif; ?>
				</div>
			</div>
		</div>
	<?php endif; ?>
</div>

<script>
	document.addEventListener('DOMContentLoaded', function () {

		const countInput = document.getElementById('count');
		const orderPrice = document.getElementById('order-price');

		if (!countInput || !orderPrice) return;

		countInput.addEventListener('input', () => {
			const countValue = parseFloat(countInput.value);

			if (!isNaN(countValue)) {
				const newPrice = countValue * <?php echo $service->rate;?>;
				orderPrice.textContent = newPrice.toFixed(2);
			} else {
				orderPrice.textContent = '…';
			}
		});
	})
</script>
