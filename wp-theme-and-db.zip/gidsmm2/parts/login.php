
<section class="fluid-container">
	<div class="back">
		<form class="welcome-form">
			<div class="welcome-form__main">
				<h1 class="welcome-form__title">Авторизация</h1>
				<fieldset class="welcome-form__fieldset">
					<input class="input welcome-form__input-text" type="text" placeholder="E-mail">
					<input class="input welcome-form__input-text" type="text" placeholder="Пароль">
				</fieldset>
				<div class="welcome-form__note">Я соглашаюсь, что ознакомлен с <a class="link" href="/legal.html">политикой&nbsp;конфеденциальности</a></div>
				<div><a class="btn btn_extra btn_primary" href="">Войти</a></div>
			</div>
			<footer class="welcome-form__footer">
				<div>Нет аккаунта? <a href="/registration.html">Создать</a></div>
				<div class="welcome-form__mega-link"><a href="/password-reset.html">Я забыл пароль</a></div>
			</footer>
		</form>
	</div>
</section>