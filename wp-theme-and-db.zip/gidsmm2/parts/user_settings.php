<p>user_settings!</p>


<?php

echo do_shortcode('ultimatemember_account');