				<div>Я соглашаюсь, что ознакомлен с <a href="/legal" class="plain-link">политикой конфеденциальности</a></div>
			</div>
			<footer class="welcome-form__footer">
				<div>Есть аккаунт? <a href="/login">Войти</a></div>
			</footer>
		</div>
	</div>
</section>