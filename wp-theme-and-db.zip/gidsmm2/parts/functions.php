<section class="container">
	<div class="functions">
		<h2 class="functions__title">Функции сервиса</h2>
		<div class="functions__detail">
			<section class="function">
				<div class="function__icon icon-like"></div>
				<div class="function__main">
					<div class="function__title">Мне&nbsp;нравится</div>
					<div class="function__text">Лайки, классы и реакции</div>
				</div>
			</section>
			<section class="function">
				<div class="function__icon icon-friend"></div>
				<div class="function__main">
					<div class="function__title">Подписчики</div>
					<div class="function__text">Лучшие на рынке офферного типа</div>
				</div>
			</section>
			<section class="function">
				<div class="function__icon icon-heart"></div>
				<div class="function__main">
					<div class="function__title">Комментарии</div>
					<div class="function__text">На посты, фото или видео</div>
				</div>
			</section>
			<section class="function">
				<div class="function__icon icon-eye"></div>
				<div class="function__main">
					<div class="function__title">Просмотры</div>
					<div class="function__text">На посты, фото или видео</div>
				</div>
			</section>
		</div>
	</div>
</section>