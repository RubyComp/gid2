<section class="container">
	<div class="functions-light">
		<div class="functions-light__header">
			<h2 class="functions-light__title">Работаем на&nbsp;совесть</h2>
			<div class="functions-light__subtitle">Выполнили более 100 000 заказов.</div>
		</div>
		<div class="functions-light__detail">
			<section class="function-light">
				<div class="function-light__icon icon-like"></div>
				<div class="function-light__main">
					<div class="function-light__title">Надежность</div>
					<div class="function-light__text">Тысячи довольных клиентов уже пользуются нашими услугами и остаются довольны.</div>
				</div>
			</section>
			<section class="function-light">
				<div class="function-light__icon icon-friend"></div>
				<div class="function-light__main">
					<div class="function-light__title">Низкие цены</div>
					<div class="function-light__text">У нас самые низкие цены на рынке и отличное качество аудитории.</div>
				</div>
			</section>
			<section class="function-light">
				<div class="function-light__icon icon-heart"></div>
				<div class="function-light__main">
					<div class="function-light__title">100% выполнение заказов</div>
					<div class="function-light__text">Если Ваш заказ не был выполнен — мы вернем Вам денежные средства в полном объеме.</div>
				</div>
			</section>
			<section class="function-light">
				<div class="function-light__icon icon-eye"></div>
				<div class="function-light__main">
					<div class="function-light__title">Помощь</div>
					<div class="function-light__text">Поможем в любое время в тикетах или в онлайн чате.</div>
				</div>
			</section>
		</div>
	</div>
</section>