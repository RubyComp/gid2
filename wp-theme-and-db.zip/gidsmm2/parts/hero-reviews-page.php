<section class="fluid-container mini-hero hero-feed">
	<div class="mini-hero__content">
		<div class="container">
			<article class="mini-hero__article">
				<?php
					echo generateBreadcrumbs($breadcrumbs = [
						['title' => 'Отзывы']
					]);
				?>
				<h1 class="mini-hero__title">Отзывы наших клиентов</h1>
				<div class="mini-hero__text">Ознакомьтесь с&nbsp;отзывами наших клиентов или&nbsp;напишите свой, без&nbsp;ссылок, спама и&nbsp;нецензурной лексики</div>
			</article>
			<div class="inline-btns mini-hero__actions">
				<a href="/feedback-form" class="btn btn_light btn_action btn_up-next">Написать отзыв</a>
			</div>
		</div>
	</div>
</section>