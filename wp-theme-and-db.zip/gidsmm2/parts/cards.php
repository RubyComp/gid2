<section>
	<div class="container">
		<h2 class="title title_focus">Популярные услуги</h2>
	</div>
	<div class="container cards-container">
		<section class="card">
			<div class="card__label">Услуга</div>
			<div class="card__image"><img src="<? echo get_template_directory_uri() ?>/assets/images/telegram-promo.png" alt="Telegram"></div>
			<article class="card__desc">
				<header class="card__title">Telegram</header>
				<p class="card__text">Заполненные профили, мгновенный запуск заказа. Без списаний.</p>
				<footer class="card__price"><b class="card__price-value">500</b><small class="card__price-note">₽ / 1000 подписчиков</small></footer>
			</article>
			<div class="card__actions"><a href="/catalog" class="btn btn_primary">Оформить заказ</a></div>
		</section>
		<section class="card">
			<div class="card__label">Услуга</div>
			<div class="card__image"><img src="<? echo get_template_directory_uri() ?>/assets/images/vk-promo.png" alt="vk"></div>
			<article class="card__desc">
				<header class="card__title">Вконтакте</header>
				<p class="card__text">Добавление подписчиков с большой скоростью и лимитами.</p>
				<footer class="card__price"><b class="card__price-value">500</b><small class="card__price-note">₽ / 1000 подписчиков</small></footer>
			</article>
			<div class="card__actions"><a href="/catalog" class="btn btn_primary">Оформить заказ</a></div>
		</section>
		<section class="card">
			<div class="card__label">Услуга</div>
			<div class="card__image"><img src="<? echo get_template_directory_uri() ?>/assets/images/instagram-promo.png" alt="Instagram"></div>
			<article class="card__desc">
				<header class="card__title">Instagram</header>
				<p class="card__text">Подписчики с реальными публикациями, аватарками и именами.</p>
				<footer class="card__price"><b class="card__price-value">500</b><small class="card__price-note">₽ / 1000 подписчиков</small></footer>
			</article>
			<div class="card__actions"><a href="/catalog" class="btn btn_primary">Оформить заказ</a></div>
		</section>
		<section class="card">
			<div class="card__label">Услуга</div>
			<div class="card__image"><img src="<? echo get_template_directory_uri() ?>/assets/images/tiktok-promo.png" alt="TikTok"></div>
			<article class="card__desc">
				<header class="card__title">TikTok</header>
				<p class="card__text">Подписчики с минимальным шансом от списания. До 50К в сутки.</p>
				<footer class="card__price"><b class="card__price-value">500</b><small class="card__price-note">₽ / 1000 подписчиков</small></footer>
			</article>
			<div class="card__actions"><a href="/catalog" class="btn btn_primary">Оформить заказ</a></div>
		</section>
	</div>
</section>