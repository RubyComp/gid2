<section class="fluid-container">
	<div class="back">
		<div class="clear-um-crap welcome-form">
			<div class="welcome-form__main">
				<h1 class="welcome-form__title">Создать аккаунт</h1>