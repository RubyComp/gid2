<section class="fluid-container mini-hero hero-faq">
	<div class="mini-hero__content">
		<div class="container">
			<article class="mini-hero__article">
				
				<?php
					/* <!-- <div class="mini-hero__label"><a href="/">Главная</a> / <a href="/page">Раздел</a> / Подраздел</div> --> */

					echo generateBreadcrumbs($breadcrumbs = [
						['title' => 'Помощь']
					]);

				?>
				<h1 class="mini-hero__title">Ваши популярные вопросы</h1>
				<div class="mini-hero__text">Ознакомьтесь с нашей рубрикой популярных вопросов о нашем сервисе. Если вы не нашли необходимый ответ, вы всегда можете у нас спросить.</div>
			</article>
			<div class="inline-btns mini-hero__actions">
				<a href="/feedback-form" class="btn btn_light btn_action btn_up-next">Задать вопрос</a>
			</div>
		</div>
	</div>
</section>