<section class="fluid-container">
	<div class="back">
		<div class="clear-a-bit-um-crap welcome-form">
			<div class="welcome-form__main">
				<h1 class="welcome-form__title">Восстановить пароль</h1>