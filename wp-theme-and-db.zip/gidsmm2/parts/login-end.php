				<div>Я соглашаюсь, что ознакомлен с <a href="/legal" class="plain-link">политикой конфеденциальности</a></div>
			</div>
			<footer class="welcome-form__footer">
				<div>Нет аккаунта? <a href="/register">Создать</a></div>
				<div class="welcome-form__mega-link">
					<a href="/password-reset/">Я забыл пароль</a>
				</div>
			</footer>
		</div>
	</div>
</section>