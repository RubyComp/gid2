<?php
function callback_lava() {

	telegramLog::write_log("Lava:\n header: \n" . print_r(getallheaders(), true));

	if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
		telegramLog::write_log('Lava no POST');
		echo 'POST required';
		return;
	}
	// {
	// 	"type":1,
	// 	"amount":"1.00",
	// 	"status":"success",
	// 	"credited":"0.95",
	// 	"order_id":"208",
	// 	"pay_time":"2023-11-09 03:37:36",
	// 	"invoice_id":"a95a5a5e-75fb-4e73-811f-de3e2de3084b",
	// 	"pay_service":"card",
	// 	"custom_fields":null,
	// 	"payer_details":"220070XXXXXX7088"
	// }

	telegramLog::write_log("Lava POST:\n" . json_encode($_POST));

	$data_input = json_decode(file_get_contents('php://input'));
	telegramLog::write_log('$data_input:'. "\n" . json_encode($data_input));

	if (
		// !property_exists($data_input, 'data') ||
		// !property_exists($data_input, 'status_check') ||
		// $data_input->status_check != true
		!(property_exists($data_input, 'status') ||
		$data_input->status == 'success')
	) {
		telegramLog::write_log('Lava payment fail');
		return;
	}

	telegramLog::write_log("Lava php://input:\n" . json_encode($data_input));

	// $data = $data_input->data;

	// Array
	// (
	// 	 [Host] => gidsmm.ru
	// 	 [X-HTTPS] => 1
	// 	 [X-Forwarded-Proto] => https
	// 	 [Connection] => close
	// 	 [Content-Length] => 242
	// 	 [Accept] => application/json
	// 	 [Authorization] => 9da3fc81c57483836f9a945a4d85fce878394c7f3bf296e11d8358e78ec4a10d
	// 	 [User-Agent] => curl/1.0
	// 	 [Content-Type] => application/json
	// )

	// check headers Authorization here //

	$headers = getallheaders();
	if (!(isset($headers["Authorization"]))) {
		echo 'Authorization error';
		return;
	}


	// $lava = new Lava();

	// $fullUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

	// $data = [
	// 	"sum" => (float)$data_input->amount,
	// 	"orderId" => $data_input->order_id,
	// 	"shopId" => $lava::SHOP_ID,
	// 	"hookUrl" => $fullUrl,
	// 	"failUrl" => $lava::REDIRECT_URL,
	// 	"successUrl" => $lava::REDIRECT_URL,
	// 	"comment" => $lava::COMMENT,
	// ];

	// $data = json_encode($data,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
	// $signature = hash_hmac('sha256', $data, $lava::TOKEN);

	// telegramLog::write_log('/// $signature' . "\n" . json_encode($signature));

	// $key = explode(" ", $headers["Authorization"])[1];

	// if ($key !== $signature) {
	// 	telegramLog::write_log('Token error');
	// 	echo 'Token error';
	// 	return;
	// }

	$invoice_id = $data_input->invoice_id;

	global $wpdb;
	$table_name = $wpdb->prefix . 'deposit_orders';
	$info = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE service_id = %s", [$invoice_id]));

	if (!$info) {
		telegramLog::write_log('Lava: cant find invoice_id');
		return;
	}
	telegramLog::write_log('$info'."\n". json_encode($info));

	if (isset($_REQUEST['pre-order']) && $_REQUEST['pre-order'] > 0) {

		telegramLog::write_log('isset($_REQUEST[\'pre-order\'])');
	
		global $wpdb;

		$table_name = $wpdb->prefix . 'pre_orders';
		$order_id = $_REQUEST['pre-order'];
	
		$query = $wpdb->prepare("SELECT id, user_id, method_id, url, count FROM " . $wpdb->prefix . "pre_orders WHERE id = %d", $order_id);

		$result = $wpdb->get_row($query);

		$service = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . $wpdb->prefix . "services_methods WHERE id = %d", $result->method_id));
	
		if ($result) {
			$api = new Api();
			$order = $api->order([
				'service' => $result->method_id,
				'link' => $result->url,
				'quantity' => $result->count,
			]);
			telegramLog::write_log('$order: ' . json_encode($order));
			if ($order) {
				telegramLog::write_log(json_encode([
					'user_id' => $result->user_id,
					'serviceId' => $service->serviceId,
					'apiId' => $service->apiId,
					'orderId' => $order->order,
					"cost" => $info->amount,
					"count" => $result->count,
					"url" => $result->url,
					"name" => $service->name,
					"date" => date("d.m.Y H:i:s")
				]));
				$wpdb->insert($wpdb->prefix . "service_orders", [
					'user_id' => $result->user_id,
					'serviceId' => $service->serviceId,
					'apiId' => $service->apiId,
					'orderId' => $order->order,
					"cost" => $info->amount,
					"count" => $result->count,
					"url" => $result->url,
					"name" => $service->name,
					"date" => date("d.m.Y H:i:s")
				]);
				telegramLog::write_log('$wpdb order');
			} else {
				telegramLog::write_log(json_encode([
					'user_id' => $result->user_id,
					'serviceId' => $service->serviceId,
					'apiId' => $service->apiId,
					"cost" => $info->amount,
					"count" => $result->count,
					"url" => $result->url,
					"name" => $service->name,
					"date" => date("d.m.Y H:i:s")
				]));
				telegramLog::write_log('NO order');
			}
			telegramLog::write_log('pre_orders order $api');
		} else {
			telegramLog::write_log('pre_orders error: cant find pre_order_id');
		}

	} else {
		deposit_funds($info->user_id, $info->amount, $info->id, $invoice_id);
		telegramLog::write_log('deposit_funds');
	}

	return true;
}