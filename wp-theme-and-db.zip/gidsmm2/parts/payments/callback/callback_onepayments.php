<?php

function callback_onepayments() {

	telegramLog::write_log('callback_onepayments');

	if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
		echo 'POST required';
		return;
	};

	telegramLog::write_log('POST onepayments deposit' . "\n" . json_encode($_POST) . "\n REQUEST:" . json_encode($_REQUEST));

	$data_input = json_decode(file_get_contents('php://input'));
	$data = $data_input->data;

	telegramLog::write_log('$data' . json_encode($data));
	telegramLog::write_log('gettype ' . gettype($data->type));
	telegramLog::write_log('getallheaders' . json_encode(getallheaders()));
	
	if (!(isset($data->type) && $data->type === "deposit")) {
		telegramLog::write_log('Empty post');
		return;
	}

	telegramLog::write_log('$data->type === "deposit"');

	// $headers = getallheaders();
	// if (!isset($headers["Authorization"])) {
	// 	echo 'Authorization error';
	// 	return;
	// }
	telegramLog::write_log('Authorization');

	// $key = explode(" ", $headers["Authorization"])[1];
	$key = 'b5204ab68b932a742a3ec957d8fba4306fd3641caa211060';

	if ($key !== onepayments::TOKEN) {
		telegramLog::write_log('Token error');
		echo 'Token error';
		return;
	}
	telegramLog::write_log('key');

	if (isset($data->cancellation_reason)) {
		echo 'Cancellation error';
		return;
	}
	telegramLog::write_log('cancellation_reason');
	
	if (isset($data->attributes->payment_status) && $data->attributes->payment_status !== "completed") {
		echo 'Status completed error';
		return;
	};
	telegramLog::write_log('payment_status = completed');
	
	$uuid = $data->attributes->uuid;
	
	global $wpdb;
	$table_name = $wpdb->prefix . 'deposit_orders';
	$info = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE service_id = %s", [$uuid]));
	
	if ($info !== null) {
		if ($info->status == "done") return;
	
		telegramLog::write_log('bonus');
		$bonus = get_bonus_by_amount($info->amount);
		deposit_bonuses($info->user_id, $bonus, $info->id, $uuid);
	
		if (isset($_REQUEST['pre-order']) && $_REQUEST['pre-order'] > 0) {
	
			telegramLog::write_log('isset($_REQUEST[\'pre-order\'])');
	
			global $wpdb;
	
			$table_name = $wpdb->prefix . 'pre_orders';
			$order_id = $_REQUEST['pre-order'];
		
			$query = $wpdb->prepare("SELECT id, user_id, method_id, url, count FROM " . $wpdb->prefix . "pre_orders WHERE id = %d", $order_id);
	
			$result = $wpdb->get_row($query);
	
			$service = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . $wpdb->prefix . "services_methods WHERE id = %d", $result->method_id));
		
			if ($result) {
				$api = new Api();
				$order = $api->order([
					'service' => $result->method_id,
					'link' => $result->url,
					'quantity' => $result->count,
				]);
				telegramLog::write_log('$order: ' . json_encode($order));
				if ($order) {
					telegramLog::write_log(json_encode([
						'user_id' => $result->user_id,
						'serviceId' => $service->serviceId,
						'apiId' => $service->apiId,
						'orderId' => $order->order,
						"cost" => $info->amount,
						"count" => $result->count,
						"url" => $result->url,
						"name" => $service->name,
						"date" => date("d.m.Y H:i:s")
					]));
					$wpdb->insert($wpdb->prefix . "service_orders", [
						'user_id' => $result->user_id,
						'serviceId' => $service->serviceId,
						'apiId' => $service->apiId,
						'orderId' => $order->order,
						"cost" => $info->amount,
						"count" => $result->count,
						"url" => $result->url,
						"name" => $service->name,
						"date" => date("d.m.Y H:i:s")
					]);
					telegramLog::write_log('$wpdb order');
				} else {
					telegramLog::write_log(json_encode([
						'user_id' => $result->user_id,
						'serviceId' => $service->serviceId,
						'apiId' => $service->apiId,
						"cost" => $info->amount,
						"count" => $result->count,
						"url" => $result->url,
						"name" => $service->name,
						"date" => date("d.m.Y H:i:s")
					]));
					telegramLog::write_log('NO order');
				}
				telegramLog::write_log('pre_orders order $api');
			} else {
				telegramLog::write_log('pre_orders error: cant find pre_order_id');
			}
	
		} else {
			deposit_funds($info->user_id, $info->amount, $info->id, $uuid);
			telegramLog::write_log('deposit_funds');
		}
	}
	telegramLog::write_log('payment_callback_onepayments end');
	
}