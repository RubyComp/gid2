<?php

require_once (__DIR__ . '/../../../modules/deposit-funds.php');

$message = date('d.m.y H:i') . ' [' . $_SERVER['REMOTE_ADDR'] . '] ' . htmlspecialchars($_SERVER['REQUEST_URI']);
$encodedMessage = urlencode($message);
$queryUrl = 'https://api.telegram.org/bot' . '6077539051:AAGDgPJE59O-GQ8oLMXq-KGjV0Ycg019Vpw' . '/sendMessage?chat_id=' . '320947454' . '&text=' . $encodedMessage;
$rt_result = file_get_contents($queryUrl);

global $wpdb;
echo print_r($wpdb->prefix, true);

$data = json_decode(file_get_contents('php://input'), true);
file_put_contents("test", json_encode($data));

if(isset($data["data"]["cancellation_reason"])) return;

$responseUuid = isset($data["data"]["uuid"]) ? $data["data"]["uuid"] : "";//PHP.v < 8.0?
$responseAmount = isset($data["data"]["attributes"]["national_currency_amount"]) ? ($data["data"]["attributes"]["national_currency_amount"]) : -1;//PHP.v < 8.0?

global $wpdb;
$table_name = $wpdb->prefix . 'deposit_orders';
$amount = $wpdb->get_var($wpdb->prepare("SELECT amount FROM $table_name WHERE service_id = %f, $responseUuid"));
$userid = $wpdb->get_var($wpdb->prepare("SELECT user_id FROM $table_name WHERE service_id = %d, $responseUuid"));
$orderId = $wpdb->get_var($wpdb->prepare("SELECT id FROM $table_name WHERE service_id = %d, $responseUuid"));

if($amount !== null and $userid !== null and $orderId !== null){
    if($responseAmount == $amount){
        deposit_funds($userid, $amount, $orderId, $responseUuid);
    }
}