<?php

require_once(__DIR__ . '/../../../modules/deposit-funds.php');
require_once(__DIR__ . '/../methods/cardlink.php');
$data = json_decode(file_get_contents('php://input'), true);

if (isset($data["OutSum"]) and isset($data["InvId"]) and isset($data["TrsId"])) {
    $signature = strtoupper(md5($data["OutSum"] . ":" . $data["InvId"] . ":" . cardlink::TOKEN));
    if (strcasecmp($signature, $data["SignatureValue"])) {
        $responseUuid = $data["TrsId"];

        global $wpdb;
        $table_name = $wpdb->prefix . 'deposit_orders';

        $amount = $wpdb->get_var($wpdb->prepare("SELECT amount FROM $table_name WHERE service_id = %f, $responseUuid"));
        $userid = $wpdb->get_var($wpdb->prepare("SELECT user_id FROM $table_name WHERE service_id = %d, $responseUuid"));
        $orderId = $wpdb->get_var($wpdb->prepare("SELECT id FROM $table_name WHERE service_id = %s, $responseUuid"));

        if ($amount !== null and $userid !== null and $orderId !== null) {
            deposit_funds($userid, $amount, $orderId, $responseUuid);
        }
    }
}