<?php

class cardlink
{

    const TOKEN = "";//TOKEN CardLink
    const SHOP_ID = "";//Уникальный ид магазина
    const PREFIX = "[CardLink] ";

    public function __construct()
    {
        require_once __DIR__ . "/log/telegramLog.php";
    }

    public function process($amount, $userid)
    {
        $new_order = $this->create_new_deposit_order($amount, $userid);

        $is_redirect = false;
        $redirect_url = "";

        if ($new_order && $new_order['ok']) {
            $service_response = $this->send_deposit_order_to_service($new_order['data']['amount'], $new_order['insert_id']);

            if(isset($service_response["success"])){
                if($service_response["success"]){
                    $updated_service_id = $this->update_servise_id($new_order['insert_id'], $service_response['bill_id']);
                    if (!$updated_service_id) {
                        telegramLog::write_log(self::PREFIX . "Неудалось обновить ServiceId:\n" . json_encode($new_order));
                    }

                    $is_redirect = true;
                    $redirect_url = $service_response['link_url'];

                }
            }else{
                telegramLog::write_log(self::PREFIX . "Ошибка при создании платежа CardLink\n" . json_encode($service_response));
            }
        }
        return ["redirect" => $is_redirect, "url" => $redirect_url];
    }

    public function send_deposit_order_to_service($amount, $order_id)
    {
        $ch = curl_init('https://cardlink.link/api/v1/bill/create');

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(array(
            "amount" => $amount,
            "order_id" => $order_id,
            "description" => "Пополнение баланса",
            "type" => "normal",
            "shop_id" => self::SHOP_ID,
            "currency_in" => "RUB",
            "custom" => "none",
            "name" => "Пополнение баланса GidSmm"
        )));
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Accept: application/json',
            'Authorization: Bearer ' . self::TOKEN,
            'Content-Type: application/json',
        ));

        $response = curl_exec($ch);
        curl_close($ch);

        return json_decode($response);
    }

    public function create_new_deposit_order($amount, $user_id)
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'deposit_orders';

        $data = array(
            'user_id' => $user_id,
            'amount' => $amount,
            'status' => 'new',
            'date' => date("d.m.Y H:i:s")
        );

        $format = array(
            '%d', // user_id
            '%f', // amount
            '%s', // status
            '%s' //date
        );

        $wpdb->insert($table_name, $data, $format);

        if ($wpdb->last_error) {
            $result = array(
                'ok' => false,
                'message' => $wpdb->last_error,
                'data' => $data
            );
        } else {
            $result = array(
                'ok' => true,
                'insert_id' => $wpdb->insert_id,
                'data' => $data
            );
        }

        return $result;
    }

    public function update_servise_id($order_id, $service_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'deposit_orders';

        $data = array('service_id' => $service_id);
        $where = array('id' => $order_id);

        return $wpdb->update($table_name, $data, $where);
    }
}