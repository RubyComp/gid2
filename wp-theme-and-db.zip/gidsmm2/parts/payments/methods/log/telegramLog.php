<?php

class telegramLog {

	const TOKEN = "*****";
	const USER_ID = "*****";

	public static function write_log($text) {
		return;
		$encodedMessage = urlencode($text);
		// $queryUrl = 'https://api.telegram.org/bot' . self::TOKEN . '/sendMessage?chat_id=' . self::USER_ID . '&text=' . $encodedMessage;
		// file_get_contents($queryUrl);
	}
}