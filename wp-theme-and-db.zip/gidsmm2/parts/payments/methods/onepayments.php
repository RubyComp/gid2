<?php

class onepayments
{

    const TOKEN = "b5204ab68b932a742a3ec957d8fba4306fd3641caa211060"; //Токен OnePayments
    const CALLBACK_URL = "https://gidsmm.ru/wp-json/gridsmm/v1/callback/onepayments/"; //Callback от площадки
    const REDIRECT_URL = "https://gidsmm.ru/balance/"; //Куда вернуть когда прошла покупка

    const PREFIX = "[OnePayments] ";

    public function __construct()
    {
        require_once(__DIR__ . '/../../../modules/deposit-funds.php');
        // require(__DIR__ . '/log/telegramLog.php');
    }

    public function process($amount, $userid, $pre_order_id = 0)
    {

        $new_order = $this->create_new_deposit_order($amount, $userid);

        telegramLog::write_log(self::PREFIX . "process:\n" . $userid . "\n" . json_encode($new_order));

        $is_redirect = false;
        $redirect_url = "";

        if ($new_order && $new_order['ok'] === true) {

            $service_response = $this->send_deposit_order_to_service($new_order['data']['amount'], $new_order['insert_id'], $pre_order_id);

            telegramLog::write_log(self::PREFIX . "service_response:\n" . $userid . "\n" . json_encode($service_response));

            if (property_exists($service_response, 'errors')) {
                $errors = $service_response->errors;
                telegramLog::write_log(self::PREFIX . "error at send_deposit_order_to_service:\n" . json_encode($errors) . "\n" . json_encode($new_order));
            } else if (property_exists($service_response, 'data')) {

                $respons_info = $this->get_response_info($service_response);

                if ($respons_info['ok'] === true && $respons_info['data']['url']) {
                    $updated_service_id = $this->update_servise_id($new_order['insert_id'], $respons_info['data']['id']);
                    if (!$updated_service_id) {
                        telegramLog::write_log(self::PREFIX . "error at updated_service_id:\n" . json_encode($respons_info) . "\n" . json_encode($new_order));
                    }
                    $is_redirect = true;
                    $redirect_url = $respons_info['data']['url'];

                    // TEST ONLY:
                    //deposit_funds($new_order['data']['user_id'], $new_order['data']['amount'], $new_order['insert_id'], $respons_info['data']['id']);

                } else {
                    telegramLog::write_log(self::PREFIX . 'error at respons_info.' . json_encode($respons_info) . "\n" . $service_response);
                }

            } else {
                telegramLog::write_log(self::PREFIX . 'error at send_deposit_order_to_service error.' . json_encode($new_order));
            }

        } else {
            telegramLog::write_log(self::PREFIX . 'error at new_order: amount - ' . $_POST['amount'] . ' / user_id - ' . get_user_id());
        }
        return ["redirect" => $is_redirect, "url" => $redirect_url];
    }

    public function send_deposit_order_to_service($amount, $order_id, $pre_order_id = 0)
    {
        $ch = curl_init('https://onepayments.tech/api/v1/payments/deposits');

        if (isset($pre_order_id) && $pre_order_id > 0) {
            $callback_with_pre_order = self::CALLBACK_URL . '?pre-order=' . $pre_order_id;
            telegramLog::write_log('PRE-ORDER');
        } else {
            $callback_with_pre_order = self::CALLBACK_URL;
            telegramLog::write_log('NO-PRE-ORDER');
        }
        telegramLog::write_log(self::PREFIX . "process callback_with_pre_order:\n" . $callback_with_pre_order);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(array(
            "national_currency" => "RUB",
            "national_currency_amount" => $amount,
            "external_order_id" => $order_id,
            "locale" => "ru",
            "redirect_url" => self::REDIRECT_URL,
            "callback_url" => $callback_with_pre_order
        )));
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Accept: application/json',
            'Authorization: Bearer ' . self::TOKEN,
            'Content-Type: application/json',
        ));

        $response = curl_exec($ch);
        curl_close($ch);
        // telegramLog::write_log(self::PREFIX . "\n" . json_decode($response));

        return json_decode($response);
    }

    public function create_new_deposit_order($amount, $user_id)
    {

        global $wpdb;
        $table_name = $wpdb->prefix . 'deposit_orders';

        $data = array(
            'user_id' => $user_id,
            'amount' => $amount,
            'status' => 'new',
            'date' => date("d.m.Y H:i:s")
        );

        $format = array(
            '%d', // user_id
            '%f', // amount
            '%s', // status
            '%s' //date
        );

        $wpdb->insert($table_name, $data, $format);

        if ($wpdb->last_error) {
            $result = array(
                'ok' => false,
                'message' => $wpdb->last_error,
                'data' => $data
            );
        } else {
            $result = array(
                'ok' => true,
                'insert_id' => $wpdb->insert_id,
                'data' => $data
            );
        }

        return $result;
    }

    public function get_response_info($response)
    {

        $er_code = 0;

        if (property_exists($response, 'data')) {
            $data = $response->data;
            if (property_exists($data, 'id') && property_exists($data, 'attributes') && property_exists($data->attributes, 'url')) {
                $id = $data->id;
                $url = $data->attributes->url;

                if (!empty($id) && !empty($url)) {
                    $result = array(
                        'ok' => true,
                        'data' => array(
                            'id' => $id,
                            'url' => $url,
                        )
                    );
                } else {
                    $er_code = 1;
                    telegramLog::write_log(self::PREFIX . 'error at get_response_info: code 1' . json_encode($response));
                }
            } else {
                $er_code = 2;
                telegramLog::write_log(self::PREFIX . 'error at get_response_info: code 2' . json_encode($response));
            }
        } else {
            $er_code = 3;
        }

        if ($er_code > 0) {
            $result = array(
                'ok' => false
            );
            telegramLog::write_log(self::PREFIX . 'error at get_response_info: code ' . $er_code . json_encode($response));
        }
        return $result;
    }

    public function update_servise_id($order_id, $service_id)
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'deposit_orders';

        $data = array('service_id' => $service_id);
        $where = array('id' => $order_id);

        return $wpdb->update($table_name, $data, $where);
    }
}