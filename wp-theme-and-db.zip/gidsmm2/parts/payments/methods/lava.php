<?php

// sum*
// float	Сумма выставленного счета. Пример: 10.00

// orderId*
// string | int	Уникальный идентификатор платежа в системе мерчанта

// signature**
// string	Подпись запроса

// shopId*
// uuid	Идентификатор проекта

// hookUrl
// string | null (Max: 500)	Куда отправлять хук

// failUrl
// string | null (Max: 500)	Куда перенаправлять при не успешной оплате

// successUrl
// string | null (Max: 500)	Куда перенаправлять при успешной оплате

// expire
// int	Время жизни инвойса в минутах макс 5 дней ( По умолчанию 5 часов)

// customFields
// string (max:500)	Дополнительные поля при выставлении счёта

// comment
// string (max:255)	Комментарий выставленного счёта

// includeService
// array	Методы оплаты доступные на странице счёта

// excludeService
// array	Методы оплаты доступные на странице счёта



class lava
{

	const TOKEN = "c1bd1650c997f22097fcd9236745abc70611dab5";//TOKEN Lava
	const CALLBACK_URL = "https://gidsmm.ru/wp-json/gridsmm/v1/callback/lava/";//Куда отправлять запрос когда прошла покупка
	const SHOP_ID = "81eecc4f-d629-455e-8aaf-5442992c31f6";//Идентификатор магазина
	const REDIRECT_URL = "https://gidsmm.ru/balance/";//Куда вернуть когда прошла покупка

	const COMMENT = "Пополнение баланса GidSmm";
	const PREFIX = "[Lava] ";

	public function __construct()
	{
		require_once __DIR__ . "/log/telegramLog.php";
	}

	public function process($amount, $userid, $pre_order_id = 0)
	{
		$new_order = $this->create_new_deposit_order($amount, $userid);

		$is_redirect = false;
		$redirect_url = "";

		if ($new_order && $new_order['ok']) {
			$service_response = $this->send_deposit_order_to_service($new_order['data']['amount'], $new_order['insert_id'], $pre_order_id);
			telegramLog::write_log('$service_response'."\n" . json_encode($service_response));
			
			telegramLog::write_log('service_response->data'."\n" . json_encode($service_response->data));

			if (
				property_exists($service_response, 'status_check')
				&& $service_response->status_check == true
				&& property_exists($service_response, 'data')
			) {
				$response_data = $service_response->data;

				$updated_service_id = $this->update_servise_id(
					$new_order['insert_id'],
					$response_data->id
				);

				if (!$updated_service_id) {
					telegramLog::write_log(self::PREFIX . "Не удалось обновить ServiceId:\n" . json_encode($new_order));
				}

				$is_redirect = true;
				$redirect_url = $response_data->url;

			} else {
				telegramLog::write_log(self::PREFIX . "Неудачный запрос\n" . json_encode($service_response));
			}
		}
		return ["redirect" => $is_redirect, "url" => $redirect_url];
	}

	public function create_new_deposit_order($amount, $user_id)
	{
		global $wpdb;
		$table_name = $wpdb->prefix . 'deposit_orders';

		$data = array(
			'user_id' => $user_id,
			'amount' => $amount,
			'status' => 'new',
			'date' => date("d.m.Y H:i:s")
		);

		$format = array(
			'%d', // user_id
			'%f', // amount
			'%s', // status
			'%s' //date
		);

		$wpdb->insert($table_name, $data, $format);

		if ($wpdb->last_error) {
			$result = array(
				'ok' => false,
				'message' => $wpdb->last_error,
				'data' => $data
			);
		} else {
			$result = array(
				'ok' => true,
				'insert_id' => $wpdb->insert_id,
				'data' => $data
			);
		}

		return $result;
	}

	public function send_deposit_order_to_service($amount, $order_id, $pre_order_id = 0)
	{
		$ch = curl_init('https://api.lava.ru/business/invoice/create');

		if (isset($pre_order_id) && $pre_order_id > 0) {
			$callback_with_pre_order = self::CALLBACK_URL . '?pre-order=' . $pre_order_id;
			telegramLog::write_log('PRE-ORDER');
		} else {
			$callback_with_pre_order = self::CALLBACK_URL;
			telegramLog::write_log('NO-PRE-ORDER');
		}
		telegramLog::write_log(self::PREFIX . "process callback_with_pre_order:\n" . $callback_with_pre_order);

		$data = [
			"sum" => (float)$amount,
			"orderId" => $order_id,
			"shopId" => self::SHOP_ID,
			"hookUrl" => $callback_with_pre_order,
			"failUrl" => self::REDIRECT_URL,
			"successUrl" => self::REDIRECT_URL,
			"comment" => self::COMMENT,
		];

		$data = json_encode($data,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
		$signature = hash_hmac('sha256', $data, self::TOKEN);

		telegramLog::write_log('$signature' . "\n" . json_encode($signature));

		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(
			'Accept: application/json',
			'Signature: ' . $signature,
			'Content-Type: application/json',
		));
		telegramLog::write_log('$data:' . "\n" . json_encode($data));

		$response = curl_exec($ch);
		telegramLog::write_log('$response:' . "\n" . json_encode($response));
		curl_close($ch);

		return json_decode($response);
	}

	public function update_servise_id($order_id, $service_id)
	{
		global $wpdb;
		$table_name = $wpdb->prefix . 'deposit_orders';

		$data = array('service_id' => $service_id);
		$where = array('id' => $order_id);

		return $wpdb->update($table_name, $data, $where);
	}

}