<?php

// require_once (__DIR__ . '/payments/methods/onepayments.php');
// require_once (__DIR__ . '/payments/methods/cardlink.php');
// require_once (__DIR__ . '/payments/methods/lava.php');
// require_once (__DIR__ . '/..	/modules/deposit-funds.php');
// require_once (__DIR__ . '/../modules/bonuses.php');
// require_once (__DIR__ . '/../modules/Api.php');
require_once (__DIR__ . '/../actions/balance.php');

$process = null;

function get_user_id() {
	$current_user = wp_get_current_user();
	return $current_user->ID;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

	telegramLog::write_log('POST deposit' . "\n" . json_encode($_POST) . "\n REQUEST:" . json_encode($_REQUEST));

	switch ($_POST["payment"] ?? "non") {
		case "onepayments":
			telegramLog::write_log('onepayments deposit');
			$payment = new onepayments();
			break;
		case "lava":
			telegramLog::write_log('lava deposit');
			$payment = new lava();
			break;
		default:
			return;
	}
	$process = $payment->process($_POST['amount'], get_user_id());
	telegramLog::write_log('process end');

} else if (!is_user_logged_in()) {
	wp_redirect( home_url( '/login' ) );
}

?>

<?php

if (!is_user_logged_in())
	die;

function render_all_payment_labels() {
	$list = get_payment_methods();

	$if_first = true;

	foreach ($list as $key => $value) {
		render_payment_label($value['name'], 32, $if_first);
		$if_first = false;
	}
}

function render_payment_label($name, $height, $checked = false) {

	$code_name = strtolower($name);
	$logo_path = get_template_directory_uri() . '/assets/images/logos/' . $code_name . '-logo.svg';

	$height_px = $height . 'px';

	if ($checked) {
		$checked_attr = 'checked';
	} else {
		$checked_attr = '';
	}

	echo <<<HTML
	<label for="payment-$code_name">
		<img src="$logo_path" alt="$name">
		<input type="radio" name="payment" id="payment-$code_name" value="$code_name" $checked_attr>
		<span>$name</span>
	</label>
	HTML;

}

function get_bonus_table($list) {
	$table = '<table class="sale"><tbody><tr>';
	$tfoot = '</tbody><tfoot><tr>';

	foreach ($list as $amount => $percent) {
		$table .= '<th>' . $percent . '%</th>';
		$tfoot .= '<td>' . number_format($amount, 0, '', ' ') . '₽</td>';
	}

	$table .= '</tr></tbody>';
	$tfoot .= '</tr></tfoot></table>';

	return $table . $tfoot;
}

?>
<?php include(__DIR__ . '/../modules/users-only.php'); ?>

<div class="container">

	<?php if (is_user_logged_in() && $process !== null && $process["redirect"]): ?>

		<div class="block">
			<h1>Перенаправление на сайт платёжной системы</h1>
			<br>
			<p>Если перенаправление не произошло автоматически, нажмите на ссылку:</p>
			<div style="max-width:760px; line-height:1.25em; margin-top:.25em;">
				<small><a href="<?php echo $process["url"]; ?>"><?php echo $process["url"]; ?></a></small>
			</div>
			<br>
		</div>
		<script>
			window.location.href = '<?php echo $process["url"]; ?>';
		</script>

	<?php else: ?>

	<div class="account">

		<?php require(__DIR__ . '/../modules/account-aside.php'); ?>

		<?php
			$bonusesJSON = json_encode(get_bonuses_list());
			echo ('<script>window.bonusesList = ' . $bonusesJSON . '</script>');
		?>

		<div class="account__main">
			<div class="account__block">
				<div class="bread">Личный кабинет / Пополнение баланса</div>
				<h1 class="account__title">Пополнить баланс</h1>
				<div class="fund">
					<div class="fund__main">
						<form method="POST">
							<fieldset>
								<legend>Сумма пополнения</legend>
								<div class="extra-input extra-input_glass">
									<input type="number" value="1000" min="1" id="amount" name="amount">
									<div class="extra-input__aside">
										<div class="extra-input__mark">+<span id="bonus-cur-percent">0</span>%</div>
										<div class="extra-input__suffix">₽</div>
									</div>
								</div>
								<div class="funds-propose-list">
									<input class="funds-propose" type="button" value="500">
									<input class="funds-propose" type="button" value="1000">
									<input class="funds-propose" type="button" value="5000">
									<input class="funds-propose" type="button" value="15000">
								</div>
								<div class="funds-note">
									<div class="funds-note__head">
										<div>Вам будет зачислено</div>
										<div class="funds-note__total"><b id="balance-bonus">…</b><span>₽</span></div>
									</div>
									<div class="funds-note__footer">
										<div class="funds-note__value">
											<div>Ваш бонус:</div>
											<div><span id="bonus-amount">…</span>&nbsp;₽</div>
										</div>
										<div id="bonus-more-section">Вам осталось еще <b><span id="bonus-more">…</span>&nbsp;₽</b> до&nbsp;<span id="bonus-percent">3</span>%</div>
									</div>
								</div>
							</fieldset>
							<fieldset>
								<legend>Выберите метод оплаты:</legend>
								<div class="funds-select-list">
									<?php render_all_payment_labels(); ?>
									<!-- <label for="fund-1"><img src="<? /* echo get_template_directory_uri() */ ?>/assets/images/payments/qiwi.svg" alt="">
										<input type="radio" name="fund" id="fund-1"><span>Банковская карта</span>
									</label>
									<label for="fund-2"><img src="<? /* echo get_template_directory_uri() */ ?>/assets/images/payments/qiwi.svg" alt="">
										<input type="radio" name="fund" id="fund-2"><span>YooMoney</span>
									</label> -->
								</div>
							</fieldset>
							<button type="submit" class="btn btn_primary">Пополнить баланс</button>
						</form>
					</div>
					<aside class="fund__aside">
						<h2>Система бонусов</h2>
						<?php
							echo get_bonus_table(get_bonuses_list());
						?>
						<div class="note">
							<div class="note__icon icon-warn"></div>
							<div class="note__text">Если у&nbsp;платежной системы есть ограничения на одну транзакцию, то пополняйте частями в&nbsp;течение часа и напишите нам в&nbsp;техническую поддержку. Вам выдадут оставшийся бонус.</div>
						</div>
						<div class="fund__disclaimer">
							<div class="fund__text">Если у вас возникли проблемы с&nbsp;оплатой, свяжитесь с&nbsp;менеджером</div><a class="btn btn_glass-color" href="/contacts">Написать в&nbsp;поддержку</a>
						</div>
					</aside>
				</div>
			</div>
		</div>

	</div>

	<?php endif; ?>

</div>