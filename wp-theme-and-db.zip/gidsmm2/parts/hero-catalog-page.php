<?php

global $wpdb;
$services = $wpdb->get_results("SELECT id, name, code FROM wp_services");

$selected_service = isset($_GET['service']) ? $_GET['service'] : null;

$selected_service_data = null;

if ($selected_service) {
	foreach ($services as $service) {
		if ($service->code === $selected_service) {
				$selected_service_data = $service;
				break;
		}
	}
}

if ($selected_service_data) {
	$selected_id = $selected_service_data->id;
	$selected_name = $selected_service_data->name;
	$selected_code = $selected_service_data->code;

	global $selected_service_code;
	$selected_service_code = $selected_code;
	
} else {
	
	if (!empty($services) && isset($services[0])) {
		$selected_id = $services[0]->id;
		$selected_name = $services[0]->name;
		$selected_code = $services[0]->code;

		global $selected_service_code;
		$selected_service_code = $selected_code;
	} else {
		$selected_id = '';
		$selected_name = '';
		$selected_code = '';
	}
}

?>

<script>
	window.selectedService = {
		id: '<?php echo $selected_id; ?>',
		code: '<?php echo $selected_name; ?>',
		name: '<?php echo $selected_code; ?>',
	};
</script>

<section class="fluid-container mini-hero hero-catalog">
	<div class="mini-hero__content">
		<div class="container">
			<article class="mini-hero__article">
				<?php
					echo generateBreadcrumbs($breadcrumbs = [
						['title' => 'Каталог услуг']
					]);
				?>
				<h1 class="mini-hero__title">Накрутить <?php echo $selected_name; ?> - быстро и&nbsp;качественно</h1>
				<div class="mini-hero__text">Раскрутите <?php echo $selected_name; ?> канал. Накрутка живых подписчиков, просмотров, реакции и&nbsp;других активностей в&nbsp;одном месте.</div>
			</article>
			<div class="inline-btns mini-hero__actions"></div>
		</div>
	</div>
</section>