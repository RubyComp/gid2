<?php include(__DIR__ . '/../modules/users-only.php'); ?>

<div class="container">
	<div class="account">

		<?php require(__DIR__ . '/../modules/account-aside.php'); ?>

		<div class="account__main">
			<div class="account__block">
				<div class="bread">Личный кабинет / Ваши заказы</div>
				<h1 class="account__title">Ваши заказы</h1>

					<?php
						global $wpdb;
						$orders = $wpdb->get_results($wpdb->prepare("SELECT * FROM " . $wpdb->prefix . "service_orders WHERE user_id = %d ORDER BY id DESC", wp_get_current_user()->ID), ARRAY_A);

						if (!$orders) {
							$placeholder_img_path = get_template_directory_uri() . '/assets/images/hand.png';
							echo <<<HTML
								<div class="placeholder-image"><img src="$placeholder_img_path"></div>
								<div class="message">
									<div class="message__main">
										<div class="message__title">Заказов не найдено</div>
										<div class="message__text">Сделай свой первый шаг к популярности</div>
									</div>
									<div class="message__aside">
										<div class="btn btn_primary">Создать заказ</div>
									</div>
								</div>
							HTML;
						} else {
							echo '<div class="orders-list">';
							foreach ($orders as $order) {
								$icon = get_template_directory_uri() . '/assets/images/icons/' . 'telegram' . '.svg';

								$date = $order['date'];
								$name = $order['name'];
								$count = $order['count'];
								$url = $order['url'];
								$cost = $order['cost'];
								$cur = '₽';
								$img_path = get_template_directory_uri() . '/assets/images/social/telegram.svg';

								echo <<<HTML
								<section class="order">
									<div class="order__main">
										<header class="order__header">
											<div class="order__icon"><img src="$img_path" alt="Telegram"></div>
											<div class="order__title">
												<div class="order__date">$date</div>
												<div class="order__name">$name</div>
											</div>
										</header>
										<div class="order__detail">
											<div class="order__value">
												<div class="icon icon-user-plus"></div><span>$count шт</span>
											</div>
											<div class="order__value">
												<div class="icon icon-link"></div><span>$url</span>
											</div>
										</div>
									</div>
									<aside class="order__aside">
										<div class="order__price">
											<div class="order__price-title">Стоимость</div>
											<div class="order__price-text"><b class="order__price-value">$cost</b><small class="order__price-note">$cur</small></div>
										</div>
										<div class="btn btn_glass">Повторить заказ</div>
									</aside>
								</section>

								HTML;

							}
							echo '</div>';
						}
					?>

					<!-- <section class="order">
						<div class="order__main">
							<header class="order__header">
								<div class="order__icon"><img src="<? echo get_template_directory_uri() ?>/assets/images/social/telegram.svg" alt="Telegram"></div>
								<div class="order__title">
									<div class="order__date">18.10.2023</div>
									<div class="order__name">Подписчики Телеграм «Эконом»</div>
								</div>
							</header>
							<div class="order__detail">
								<div class="order__value">
									<div class="icon icon-user-plus"></div><span>250 шт</span>
								</div>
								<div class="order__value">
									<div class="icon icon-link"></div><span>https://t.me/sdfsdffa</span>
								</div>
							</div>
						</div>
						<aside class="order__aside">
							<div class="order__price">
								<div class="order__price-title">Стоимость</div>
								<div class="order__price-text"><b class="order__price-value">240</b><small class="order__price-note">₽</small></div>
							</div>
							<div class="btn btn_glass">Повторить заказ</div>
						</aside>
					</section> -->
				<!-- <div class="paginator">
					<div><a class="paginator__prev" href=""></a></div>
					<ul class="paginator__numbers">
						<li><a class="selected" href="">1</a></li>
						<li><a href="">2</a></li>
						<li><a href="">3</a></li>
					</ul>
					<div><a class="paginator__next" href=""></a></div>
				</div> -->
			</div>
		</div>
	</div>
</div>