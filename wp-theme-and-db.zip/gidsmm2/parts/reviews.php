
<div class="container">
	<div class="feeds">
		<div class="feeds__column">
			<?php

			$posts_per_page = 10;

			function gen_rating_html($rating) {
				if ($rating < 0 || $rating > 5) {
					return;
				}

				$output = '<div class="stars">';

				for ($i = 1; $i <= 5; $i++) {
					if ($i <= $rating) {
						$output .= '<div class="star"></div>';
					} else {
						$output .= '<div class="star star_grey"></div>';
					}
				}

				$output .= '</div>';

				return $output;
			}

			$current_page = get_query_var('paged') ? get_query_var('paged') : 1;

			$args = array(
				'post_type' => 'post',
				'category_name' => 'feeds',
				'posts_per_page' => $posts_per_page,
				'paged' => $current_page
			);

			$query = new WP_Query($args);

			if ($query->have_posts()) {
				$post_count = 0;
				$total_posts = $query->found_posts;


				while ($query->have_posts()) {
						$query->the_post();

						$name = get_field('name');
						$feed_date = get_field('feed_date');
						$text = get_the_content();

						$rating = get_field('rating');
						$rating_html = gen_rating_html($rating);

						if ($post_count == $total_posts / 2) {
							echo '</div><div class="feeds__column">';
						}

						echo <<<HTML
						<section class="feed">
							<header class="feed__header">
								<div class="feed__name">$name</div>
								<div class="feed__date-container">
									<div class="feed__date">$feed_date</div>
								</div>
								<div class="feed__rating">
									$rating_html
								</div>
							</header>
							<div class="feed__text">
								$text
							</div>
						</section>
						HTML;

						$post_count++;

				}
				wp_reset_postdata();
			} else {
				echo 'Посты не найдены.';
			}
			?>
		</div>
	</div>
	<?php
		render_pagination($total_posts, $posts_per_page, $current_page);
	?>
	<!-- <div class="paginator">
		<div>
			<a class="paginator__prev" href=""></a>
		</div>
		<ul class="paginator__numbers">
			<li><a class="selected" href="">1</a></li>
			<li><a href="">2</a></li>
			<li><a href="">3</a></li>
		</ul>
		<div>
			<a class="paginator__next" href=""></a>
		</div>
	</div> -->
</div>