<?php

$user_id = get_current_user_id();

global $wpdb;
$table_name = $wpdb->prefix . 'bonus_out';

$user_bonuses = $wpdb->get_var($wpdb->prepare("SELECT bonuses FROM {$wpdb->prefix}user_balance WHERE user_id = %d", $user_id));


$sended_ok = false;
$sended_fail = false;
$not_enough_bonuses = false;

if (isset($_POST['submit_withdrawal'])) {

	if (is_user_logged_in()) {
		$amount = sanitize_text_field($_POST['amount']);
		$payment_service_id = sanitize_text_field($_POST['payment-id']);
		$details = sanitize_text_field($_POST['detail']);
		$date = current_time('mysql');


		if ($user_bonuses >= $amount) {
			$data = array(
				'user_id' => $user_id,
				'amount' => $amount,
				'payment_service_id' => $payment_service_id,
				'details' => $details,
				'date' => $date
			);

			$wpdb->insert($table_name, $data);
			$sended_ok = true;
			$sended_fail = false;
		} else {
			$not_enough_bonuses = true;
		}
  }
}

function render_note($text) {
	echo <<<HTML
		<div class="note note__mega">
			<div class="note__icon icon-money"></div>
			<div class="note__text">$text</div>
		</div>
	HTML;
}

?>

<div class="container">
	<div class="account">

		<?php require(__DIR__ . '/../modules/account-aside.php'); ?>

		<div class="account__main">
			<div class="account__block">
				<div class="bread">Личный кабинет / Баланс / Вывести бонусы</div>
				<?php
					if ($sended_ok) {
						render_note('Заявка на вывод принята. Она будет обработана в ближайщее время.');
					} else if ($not_enough_bonuses) {
						render_note('На вашем счёте недостаточно баллов.');
					} else if ($sended_fail) {
						render_note('При отправке запроса произошла ошибка.');
					}
				?>
				<h1 class="account__title">Вывести бонусы</h1>
				<div class="balance-detail balance-detail_compact">
					<div class="balance-detail__bonus">
						<div class="btn btn_icon btn_star">
							<div class="balance-label">
								<div class="balance-label__title">Ваши бонусы:</div>
								<div class="balance-label__value"><?php echo $user_bonuses; ?> ₽</div>
							</div>
						</div>
					</div>
					<div class="note">
						<div class="note__icon icon-warn"></div>
						<div class="note__text">1 бонус = 1 рублю</div>
					</div>
				</div>
				<form class="form" method="POST">
					<h2>Введите данные</h2>
					<section class="input-section">
						<div class="input-title">Сумма</div>
						<div class="extra-input">
							<input type="text" name="amount">
						</div>
					</section>

					
					<section class="input-section">
						<div class="input-title">Платежная система</div>
						<section class="text-select">
							<input class="text-select__input-value" type="hidden" id="payment-id" name="payment-id" autocomplete="off">
							<div class="text-select__input-container">
								<input class="text-select__input" type="text" autocomplete="off" readonly name="payment">
							</div>
							<ul class="text-select__options">

								<?php

									global $wpdb;
									$table_name = $wpdb->prefix . 'out_payment_services';
									$query = "SELECT id, name FROM $table_name";
									$results = $wpdb->get_results($query);

									if ($results) {
										foreach ($results as $result) {
											echo '<li class="text-select__option" data-value="' . $result->id . '" data-name="payment">' . $result->name . '</li>';
										}
									} else {
										echo 'Нет доступных вариантов';
									}
								?>
							</ul>
						</section>
					</section>

					<section class="input-section">
						<div class="input-title">Номер кошелька</div>
						<div class="extra-input">
							<input type="text" name="detail">
						</div>
					</section>
					<div class="form-actions">
						<input type="submit" name="submit_withdrawal" value="Вывести" class="btn btn_primary">
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
