<section class="container">
	<div class="advantages">
		<section class="advantage">
			<div>
				<div class="advantage__icon icon-persons"></div>
			</div>
			<div class="advantage__text">
				<div class="advantage__value">870 502</div>
				<div class="advantage__note">Зарегистрированных пользователей</div>
			</div>
		</section>
		<section class="advantage">
			<div>
				<div class="advantage__icon icon-time-light"></div>
			</div>
			<div class="advantage__text">
				<div class="advantage__value">7 048</div>
				<div class="advantage__note">Текущих заданий в&nbsp;работе</div>
			</div>
		</section>
		<section class="advantage">
			<div>
				<div class="advantage__icon icon-check"></div>
			</div>
			<div class="advantage__text">
				<div class="advantage__value">5 132 926</div>
				<div class="advantage__note">Заданий уже выполнено</div>
			</div>
		</section>
	</div>
</section>