<?php

require_once __DIR__ . "/payments/methods/onepayments.php";
require_once __DIR__ . "/payments/methods/cardlink.php";
require_once __DIR__ . "/payments/methods/lava.php";
require_once(__DIR__ . '/../modules/deposit-funds.php');

$process = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    function get_user_id()
    {
        $current_user = wp_get_current_user();
        return $current_user->ID;
    }

    switch ($_POST["payment"] ?? "non") {
        case "onepayments":
            $payment = new onepayments();
            break;
        case "cardlink":
            $payment = new cardlink();
            break;
        case "lava":
            $payment = new lava();
            break;

        default:
            $data = json_decode(file_get_contents('php://input'), true);
            file_put_contents(__DIR__ . "save1.yml", print_r($data, true) . " " . print_r(getallheaders(), true));

            if (isset($data["data"]["type"]) && $data["data"]["type"] == "deposit") { //todo: onepayments
                $headers = getallheaders();
                if (!isset($headers["Authorization"])) return;
                $key = explode(" ", $headers["Authorization"])[1];
                if ($key !== onepayments::TOKEN) return;

                if (isset($data["data"]["cancellation_reason"])) return;
                if ($data["data"]["attributes"]["payment_status"] !== "completed") return;
                $uuid = $data["data"]["attributes"]["uuid"];

                global $wpdb;
                $table_name = $wpdb->prefix . 'deposit_orders';
                $info = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE service_id = %s", [$uuid]));

                if ($info !== null) {
                    if ($info->status == "done") return;
                    deposit_funds($info->user_id, $info->amount, $info->id, $uuid);
                }
            }
            return;
    }
    $process = $payment->process($_POST['amount'], get_user_id());
}

?>

<?php

function render_payment_label($name, $height, $checked = false)
{

    $code_name = strtolower($name);
    $logo_path = get_template_directory_uri() . '/assets/images/logos/' . $code_name . '-logo.svg';

    $height_px = $height . 'px';

    if ($checked) {
        $checked_attr = 'checked';
    } else {
        $checked_attr = '';
    }

    echo <<<HTML
	<input type="radio" name="payment" id="payment-$code_name" value="$code_name" $checked_attr>
	<label for="payment-$code_name">
		<!-- <span>$name</span> -->
		<img src="$logo_path" height="$height" style="height:$height_px" alt="$name">
	</label>
	HTML;

}

?>

<div class="block block-reviews">
    <div class="container">
        <?php if ($process !== null and $process["redirect"]): ?>
            <div class="title">Перенаправление на сайт платёжной системы</div>
            <p>Если перенаправление не произошло автоматически, нажмите на ссылку:</p>
            <div style="max-width:760px; line-height:1.25em;"><small><a
                            href="<?php echo $process["url"]; ?>"><?php echo $process["url"]; ?></a></small></div>
            <script>
                window.location.href = '<?php echo $process["url"]; ?>';
            </script>
        <?php else: ?>
            <div>
                <a href="/dashboard"><small>< Вернуться в кабинет</small></a>
            </div>
            <div style="display:grid; grid-template-columns:1fr 2fr; grid-gap:32px;">
                <div>
                    <div class="title">Пополнение баланса</div>
                    <div class="mt-8">
                        <form class="form flex flex-col gap-2" method="POST">
                            <div class="flex flex-col items-start gap-6">
                                <!-- <label for="fieldName" class="label">Выберите способ оплаты</label>
                                <select name="selected_payments">
                                    <option value="onepayments">OnePayments</option>
                                    <option value="cardlink">CardLink</option>
                                    <option value="lava">Lava</option>
                                </select> -->
                                <label for="fieldName" class="label">Сумма (₽)</label>
                                <input class="field" id="amount" name="amount" type="number" step="1" min="1"
                                       placeholder="Введите сумму" required>
                                <div class="funds-propose-list">
                                    <input type="button" class="funds-propose" value="100">
                                    <input type="button" class="funds-propose" value="500">
                                    <input type="button" class="funds-propose" value="1000">
                                    <input type="button" class="funds-propose" value="5000">
                                </div>
                                <div>
                                    <div>Баланс после
                                        пополнения: <?php require(__DIR__ . '/../modules/user-balance.php'); ?></div>
                                </div>
                            </div>

                            <div class="mt-8">
                                <label for="fieldName" class="label">Выберите способ оплаты</label>
                                <div class="select-pay-list">
                                    <?php
                                    render_payment_label('Onepayments', 32, true);
                                    render_payment_label('CardLink', 18);
                                    render_payment_label('Lava', 32);
                                    ?>
                                </div>
                            </div>

                            <button class="btn btn-default mt-12" type="submit"><span>Пополнить</span></button>

                            <?php /*<div class="mt-8">
                                <p><strong>Режим тестового пополнения.</strong><br>Средства зачислются без оплаты.</p>
                            </div>*/?>
                        </form>
                    </div>
                </div>
                <div>
                    <?php require(__DIR__ . '/../modules/last-deposits.php'); ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
    document.addEventListener("DOMContentLoaded", function () {

        const currentBalance = parseFloat(document.querySelector(".user-balance-value").textContent) || 0;

        const updateSubmitButton = () => {
            const amountField = document.querySelector("#amount");
            const form = amountField.closest("form");

            if (form) {
                const submitButton = form.querySelector('[type="submit"]');

                if (submitButton) {
                    submitButton.classList.add("btn-highlight");
                }
            }
        }

        const updateUserBalanceValue = () => {
            const currentDeposit = parseFloat(document.querySelector("#amount").value) || 0;
            if (currentDeposit >= 0)
                document.querySelector(".user-balance-value").textContent = (currentBalance + currentDeposit).toFixed(2);
        }

        const fundsProposeElements = document.querySelectorAll(".funds-propose");

        if (fundsProposeElements.length > 0) {
            fundsProposeElements.forEach(function (element) {
                element.addEventListener("click", function () {
                    const value = element.getAttribute("value");
                    document.querySelector("#amount").value = value;

                    updateUserBalanceValue();
                    updateSubmitButton();
                });
            });
        }

        document.querySelector("#amount").addEventListener("input", function () {
            updateUserBalanceValue();
            updateSubmitButton();
        });

    });

</script>

<style>
    .funds-propose-list {
        display: flex;
        gap: 8px;
    }

    input.funds-propose {
        background-color: whitesmoke;
        border-radius: 12px;
        color: #6b6d70;
        cursor: pointer;
        font-size: 14px;
        font-weight: bold;
        padding: 4px 12px;
        transition: .12s;
    }

    .funds-propose:hover {
        opacity: .8;
    }

    .select-pay-list {
        display: flex;
        flex-direction: column;
        gap: 8px;
        margin-top: 8px;
    }

    .select-pay-list input {
        display: none;
    }

    .select-pay-list label {
        align-items: center;
        background-color: white;
        border-radius: 12px;
        color: black;
        cursor: pointer;
        display: flex;
        gap: 9px;
        height: 46px;
        outline: 2px solid #eaeaea;
        padding: 9px 14px 8px;
        transition: .12s;
    }

    .select-pay-list label:before {
        border-radius: 50%;
        border: 1px solid #eaeaea;
        content: '';
        display: block;
        height: 12px;
        margin-bottom: 1px;
        width: 12px;
    }

    .select-pay-list input:checked + label:before {
        background-color: #3483ff;
        border-color: #3483ff;
    }

    .select-pay-list label:hover {
        opacity: .8;
    }

    .select-pay-list input:checked + label {
        background-color: whitesmoke;
    }

    button.btn-highlight {
        background: linear-gradient(-45deg, rgba(205, 15, 216, .85), rgba(52, 131, 255, .85));
        color: white;
    }

    button.btn-highlight span {
        -webkit-background-clip: initial;
        -webkit-text-fill-color: initial;
        background-clip: initial;
        background: none;
        color: inherit;
    }

    .btn[type="submit"] {
        transition: .2s;
    }

    .history-table {
        border-collapse: separate;
        border-spacing: 0 5px;
        text-align: center;
        width: 100%;
    }

    .history-table caption {
        margin-bottom: 8px;
        font-weight: bold;
    }

    .history-table thead tr {
        font-weight: 500;
        color: #898789;
        width: 100%;
    }

    .history-table tbody tr {
        background-color: #F4F3F5;
        width: 100%;
    }

    .history-table tbody td:first-child {
        border-radius: 8px 0 0 8px;
    }

    .history-table tbody td:last-child {
        border-radius: 0 8px 8px 0;
    }

    .history-table tbody td {
        padding: 8px 12px
    }
</style>