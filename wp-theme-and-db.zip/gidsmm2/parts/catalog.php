<section class="container catalog">
	<h2 class="title title_focus">Что будем продвигать?</h2>
	<div class="catalog__body">
		<aside class="catalog__aside">
			<div id="services-list" class="catalog__categories-list">
				<?php
					global $wpdb;
					global $selected_service_code;

					$table_name = $wpdb->prefix . 'services';
					$services = $wpdb->get_results("SELECT id, name, code FROM $table_name");

					function item($id, $type, $text, $selected = false) {
						$css_classes = 'catalog__category';
						if ($selected) {
							$css_classes .= ' selected';
						}
						return '<button class="' . $css_classes . '" data-service-id="' . $id . '" data-service-code="' . $type . '" data-service-name="' . $type . '"><div class="catalog__category-icon"><img src="' . get_template_directory_uri() . '/assets/images/social/' . $type . '.svg" alt="Телеграм"></div><span>' . $text . '</span></button>';
					}
					if (!empty($services)) {
						// $is_first = true; ////

						foreach ($services as $service) {
							$is_selected_service = false;

							if ($selected_service_code && $selected_service_code == $service->code) {
								$is_selected_service = true;
							}

							echo item($service->id, $service->code, $service->name, $is_selected_service);
							$is_first = false;
						}
					} else {
						echo 'Нет данных о сервисах.';
					}
				?>
			</div>
		</aside>
		<div class="catalog__main">
			<div class="catalog__filter">
				<div class="catalog__filter-title">Заданные фильтры</div>
				<div id="services-filters-list" class="catalog__filter-list">
					<?php /*<!-- <button class="filter checked" data-name="Подписчики">
						<div class="icon"></div>
						<input type="checkbox" checked>
						<label for="">Подписчики</label>
					</button>
					<button class="filter" data-name="Комментарии">
						<div class="icon"></div>
						<input type="checkbox">
						<label for="">Комментарии</label>
					</button>
					<button class="filter" data-name="Лайки">
						<div class="icon"></div>
						<input type="checkbox">
						<label for="">Лайки</label>
					</button>
					<button class="filter" data-name="Активность">
						<div class="icon"></div>
						<input type="checkbox">
						<label for="">Активность</label>
					</button> -->*/?>
				</div>
			</div>
			<div id="services-items" class="catalog__list">
				<?php /*<!-- <section class="service">
					<div class="service__main">
						<div class="service__desc">
							<div class="service__title">
								<div class="service__icon"><img src="<? echo get_template_directory_uri() ?>/assets/images/social/telegram.svg" alt="Telegram"></div>
								<div class="service__name">Подписчики Телеграм «Эконом»</div>
							</div>
							<div class="service__text">Подписчики со всех стран с минимальным шансом списания. Высокая скорость. До 15к в сутки. Только публичная ссылка. Претензии не принимаются!</div>
							<footer class="service__footer">
								<div class="service__rating">
									<div class="service__rating-name">Качество</div>
									<div class="stars">
										<div class="star"></div>
										<div class="star"></div>
										<div class="star"></div>
										<div class="star"></div>
										<div class="star star_grey"></div>
									</div>
								</div>
								<div class="service__rating">
									<div class="service__rating-name">Скорость</div>
									<div class="stars">
										<div class="star"></div>
										<div class="star"></div>
										<div class="star"></div>
										<div class="star"></div>
										<div class="star star_grey"></div>
									</div>
								</div>
							</footer>
						</div>
					</div>
					<aside class="service__aside">
						<div class="service__price">
							<div class="service__price-title">Стоимость</div>
							<div class="service__price-text"><b class="service__price-value">0,55</b><small class="service__price-note">₽ / 1 штука</small></div>
						</div>
						<div class="btn btn_light">Оставить заявку</div>
					</aside>
				</section> -->*/?>
			</div>
			<!-- <button class="catalog__more">Загрузить еще</button> -->
		</div>
	</div>
</section>
