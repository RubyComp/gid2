<?php include(__DIR__ . '/../modules/users-only.php'); ?>

<div class="container">
	<div class="account">

		<?php require(__DIR__ . '/../modules/account-aside.php'); ?>

		<div class="account__main">
			<div class="account__block">
				<div class="bread">Личный кабинет / Пополнение баланса</div>
				<h1 class="account__title">Текущий Баланс</h1>
				<div class="balance-detail">
					<div class="balance-detail__main"><a class="btn btn_icon btn_rub" href="/orders">
							<div class="balance-label">
								<div class="balance-label__title">Ваш баланс:</div>
								<div class="balance-label__value">
									<?php require(__DIR__ . '/../modules/user-balance.php'); ?>
								</div>
							</div></a></div>
					<div class="balance-detail__bonus"><a class="btn btn_icon btn_star" href="/orders">
							<div class="balance-label">
								<div class="balance-label__title">Ваши бонусы:</div>
								<div class="balance-label__value">0 ₽</div>
							</div></a></div>
					<div class="balance-detail__actions"><a class="btn btn_glass-color" href="/out">Вывести на свой счет</a></div>
				</div>
				<div class="balance-section">
					<h2>История баланса</h2>
					<div class="table-wrapper">
						<div class="table-container">
							<?php require(__DIR__ . '/../modules/last-deposits.php'); ?>
						</div>
					</div>
				</div>
			</div>
		</div>

	</div>
</div>