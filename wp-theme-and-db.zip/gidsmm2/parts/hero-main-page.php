<section class="fluid-container hero">
	<div class="hero__content">
		<div class="container">
			<article class="hero__article">
				<div class="hero__label">Более 20 услуг в одном месте</div>
				<h1 class="hero__title">Накрутка Instagram*, TikTok, Telegram, ВКонтакте, YouTube</h1>
				<div class="hero__text">Мгновенная накрутка лайков, подписчиков, просмотров, комментариев</div>
			</article>
			<div class="inline-btns hero__actions">
				<a href="/catalog" class="btn btn_light btn_action btn_up-next">Каталог услуг</a>
				<a href="#services-list" class="btn btn_glass">Быстрый заказ</a>
			</div>
		</div>
	</div>
</section>