			</div>
			<footer class="welcome-form__footer">
				<div>Нет аккаунта? <a href="/register">Создать</a></div>
			</footer>
		</div>
	</div>
</section>