<?php


function get_meta($name) {
	$post_id = get_the_ID();
	$value = get_post_meta($post_id, $name, true);
	if (!empty($value)) {
		return $value;
	} else {
		return '…';
	}
}
$title = get_the_title();
$text = get_meta('text');
$email = get_meta('email');
$time = get_meta('time');
$link_text = get_meta('link_text');
$link = get_meta('link');

?>

<section class="fluid-container mega-hero hero-contact">
	<div class="mega-hero__content">
		<div class="container">
			<article class="mega-hero__article">
				<?php
					echo generateBreadcrumbs($breadcrumbs = [
						['title' => 'Контакты']
					]);
				?>
				<h1 class="mega-hero__title"><? echo $title; ?></h1>
				<div class="mega-hero__text">
				<div class="contacts-list">
					<p><? echo $text; ?></p>
					<div class="contact-item">
						<div class="contact-item__icon icon-message"></div>
						<div class="contact-item__main">
						<div class="contact-item__title">E-mail:</div><a class="contact-item__value" href=""><? echo $email; ?></a>
						</div>
					</div>
					<div class="contact-item">
						<div class="contact-item__icon icon-time"></div>
						<div class="contact-item__main">
						<div class="contact-item__title">Время работы:</div>
						<div class="contact-item__value"><? echo $time; ?></div>
						</div>
					</div>
					<?php if ($link != '…' && $link_text != '…'):?>
					<div class="mega-link"><a href="<? echo $link; ?>"><? echo $link_text; ?></a></div>
					<?php endif ?>
				</div>
				</div>
			</article>
			<div class="inline-btns mega-hero__actions">
				<a href="/contact-form" class="btn btn_light btn_action btn_up-next">Написать в поддержку</a>
			</div>
		</div>
	</div>
</section>