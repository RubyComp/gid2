<?php get_header(); ?>
<main class="main">
	<section class="fluid-container mega-hero hero-not-found">
		<div class="mega-hero__content">
			<div class="container">
				<article class="mega-hero__article">
					<div class="mega-hero__label">Главная / 404</div>
					<h1 class="mega-hero__title">Страница не найдена</h1>
					<p>
						<?php
					echo date('Y-m-d H:i:s');
					?>
 
					</p>
					<div class="mega-hero__text">Такой страницы не существует. Пожалуйста, вернитесь&nbsp;на&nbsp;главную.</div>
				</article>
				<div class="inline-btns mega-hero__actions"><a class="btn btn_light btn_action btn_up-next">На главную</a></div>
			</div>
		</div>
	</section>
</main>

<?php get_footer(); ?>