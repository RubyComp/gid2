document.addEventListener('DOMContentLoaded', function () {
	console.log('Scripts')

	////////////////////////////////
	// Burger

	const burger = document.getElementById('burger');
	const burgerMenu = document.getElementById('burger-menu');
	
	burger.addEventListener('click', function() {
		console.log(1111);
		burgerMenu.classList.toggle('active');
	});

	////////////////////////////////
	// Accordion

	const sections = document.querySelectorAll('.accordion__section')

	if (sections) {

		if (sections.length > 0) {
			sections[0].classList.add('active')
			const firstAnswer = sections[0].querySelector('.accordion__answer')
			firstAnswer.style.maxHeight = firstAnswer.scrollHeight + 'px'
		}

		function collapseAllExceptActive(activeSection) {
			sections.forEach((section) => {
					if (section !== activeSection) {
						section.classList.remove('active')
						section.querySelector('.accordion__answer').style.maxHeight = null
					}
			})
		}

		function toggleAccordion() {
			const answer = this.nextElementSibling
			const isActive = this.parentNode.classList.contains('active')
		
			collapseAllExceptActive(this.parentNode)
		
			if (isActive) {
					this.parentNode.classList.remove('active')
					answer.style.maxHeight = null
			} else {
					this.parentNode.classList.add('active')
					answer.style.maxHeight = answer.scrollHeight + 'px'
			}
		}

		sections.forEach((section) => {
			const question = section.querySelector('.accordion__question')
			question.addEventListener('click', toggleAccordion)
		})
	}

	/////////


})


const getServiceItemHtml = ({id, code, name, disc, detail, rate, min, max}) => {
	return `<section class="service" data-id="${id}" data-code="${code}" data-name="${name}" data-rate="${rate}" data-min="${min}" data-max="${max}">
		<div class="service__main">
			<div class="service__desc">
				<div class="service__title">
					<div class="service__icon"><img src="/wp-content/themes/gidsmm2/assets/images/social/${code}.svg" alt="${code}"></div>
					<div class="service__name">${name}</div>
				</div>
				<div class="service__text">${detail}</div>
				<footer class="service__footer">
					<div class="service__rating">
						<div class="service__rating-name">Качество</div>
						<div class="stars">
							<div class="star"></div>
							<div class="star"></div>
							<div class="star"></div>
							<div class="star"></div>
							<div class="star"></div>
						</div>
					</div>
					<div class="service__rating">
						<div class="service__rating-name">Скорость</div>
						<div class="stars">
							<div class="star"></div>
							<div class="star"></div>
							<div class="star"></div>
							<div class="star"></div>
							<div class="star"></div>
						</div>
					</div>
				</footer>
			</div>
		</div>
		<aside class="service__aside">
			<div class="service__price">
				<div class="service__price-title">Стоимость</div>
				<div class="service__price-text"><b class="service__price-value">${rate}</b><small class="service__price-note">₽ / 1 штука</small></div>
			</div>
			<button class="order-service-init btn btn_light">Оставить заявку</button>
		</aside>
	</section>`;
}

const getOrderItemHtml = ({id, code, name, rate, min, max}) => {
	const value = min * 10 <= max ? min * 10 : min;

	return `<section class="service-order" data-id="${id}" data-code="${code}" data-name="${name}" data-rate="${rate}" data-min="${min}" data-max="${max}">
		<div class="service-order__main">
			<div class="service-order__desc">
				<div class="service-order__title">
					<div class="service-order__icon">
						<img src="/wp-content/themes/gidsmm2/assets/images/social/${code}.svg" alt="${name}">
					</div>
					<div class="service-order__name">${name}</div>
				</div>
				<div class="fast-order__detail">
					<label for="order-url">
						<div class="fast-order__label">Добавьте ссылку:</div>
						<div class="fast-order__text">
							<div class="icon icon-link"></div>
							<input type="text" id="order-url" class="value-input" placeholder="…" required>
						</div>
					</label>
					<label for="order-count">
						<div class="fast-order__label">Укажите количество:</div>
						<div>
							<div class="icon icon-user-plus"></div>
							<div class="fast-order__number">
								<input type="button" class="count-minus">
								<input type="number" id="order-count" class="value-input" value="${value}" min="${min}" max="${max}" required>
								<input type="button" class="count-plus">
							</div>
						</div>
						<div class="fast-order__note">
							<div class="icon icon-warn"></div>
							<div>Лимиты: от ${min} до ${max}</div>
						</div>
					</label>
				</div>
			</div>
		</div>
		<aside class="service-order__aside">
			<div class="service-order__price-block">
				<div class="service-order__price">
					<div class="service-order__price-title">Ваша стоимость</div>
					<div class="service-order__price-text">
						<b class="order-service-current-price service-order__price-value">…</b><small class="service__price-note">₽</small>
					</div>
				</div>
				<!--<div class="service-order__promocode">
					<div class="service-order__price-title">Промокод</div>
					<div class="clear-input">
						<input placeholder="Введите промокод" disabled/>
					</div>
				</div>-->
			</div>
			<input type="hidden" id="order-id" value="${id}"/>
			<button class="order-service-select-pay btn btn_light">Продолжить</button>
		</aside>
	</section>`;
}

const getFilterItemHtml = ({name}) => {
	return `<button class="filter" data-name="${name}">
		<div class="icon"></div>
		<input type="checkbox">
		<label for="">${name}</label>
	</button>`;
}


const getPayBlockHtml = (list, data, container) => {
	console.log({data});

	const currentPriceBlock = container.querySelector('.order-service-current-price');
	const currentPriceValue = currentPriceBlock.textContent;

	let html = `<div class="service-pay">
		<fieldset>
		<legend>Выберите метод оплаты:</legend>
		<div class="funds-select-list">`;

	let isFirst = true;

	list.forEach(item => {
		const {name} = item;
		const code = name.toLowerCase();
		html += `<label for="payment-${code}">
			<img src="/wp-content/themes/gidsmm2/assets/images/logos/${code}-logo.svg" alt="${name}">
			<input type="radio" name="payment" id="payment-${code}" value="${code}" ${isFirst && 'checked'}>
			<span>${name}</span>
		</label>`;
		isFirst = false;
	});

	html += '</div></fieldset>';

	html += '<div class="service-pay__actions"><div><button class="order-service-pay-new btn btn_primary">Пополнить и оплатить</button></div>';

	if (parseFloat(window?.currentUser?.balance?.value) >= parseFloat(currentPriceValue))
		html += `<div><button class="order-service-pay-by-balance btn btn_glass-color">Оплатить с баланса</button></div>`;
	else
		html += '<div><button class="btn btn_glass-color" disabled>Оплатить с баланса</button><small>Недостаточно средств на счёте</small></div>';

	html += '</div></div>';

	return html;
}

const calcOrderCost = (orderBlock) => {
	const {rate} = orderBlock.dataset;
	const orderCount = parseInt(orderBlock.querySelector('#order-count').value);
	const currentPriceBlock = orderBlock.querySelector('.order-service-current-price');
	currentPriceBlock.textContent = (orderCount * parseFloat(rate)).toFixed(2);
}

const renderOrderBlock = (container, {id, code, name, rate, min, max}) => {
	console.log({id, code, name, rate, min, max});
	console.log({container});

	document.getElementById("services-items").scrollIntoView();

	container.innerHTML = getOrderItemHtml({id, code, name, rate, min, max});
	calcOrderCost(container.querySelector('.service-order'));
}


const changeOrderCount = (container, numb) => {
	const orderCountInput = container.querySelector('#order-count');
	const {min, max} = orderCountInput;
	const orderCount = parseInt(orderCountInput.value);

	if (orderCount) {
		const newValue = orderCount + numb;
		let newSafeValue = 0;
		if (newValue < min) newSafeValue = parseInt(min);
		else if (newValue > max) newSafeValue = parseInt(max);
		else newSafeValue = newValue;

		orderCountInput.value = newSafeValue;
		calcOrderCost(container)

		return true;
	} else {
		return false;
	}

}


const renderPayBlock = (container, serviceData) => {
	const id = container.querySelector('#order-id').value;
	const count = container.querySelector('#order-count').value;
	const url = container.querySelector('#order-url').value;

	if (id?.length > 0 && count?.length > 0 && url?.length) {

		fetch(`/wp-json/gridsmm/v1/payments/`)
			.then(response => response.json())
			.then(data => {
					console.log({data});
					container.querySelectorAll('.service-pay ').forEach(function(elem) {
						elem.remove();
					});
					container.querySelector('.service-order').classList.add('service-order_locked');
					container.insertAdjacentHTML('beforeend', getPayBlockHtml(data, serviceData, container));
					container.querySelectorAll('.service-order input').forEach(function(inputElement) {
						inputElement.setAttribute("readonly", "readonly");
					});
			})
			.catch(error => {
				console.error('Ошибка при выполнении GET-запроса:', error);
			});

	} else {
		alert('Необходимо указать url и количество');
	}
}

// const sendPayByBalance = (container) => {
// 	const id = container.querySelector('#order-id').value;
// 	const count = container.querySelector('#order-count').value;
// 	const url = container.querySelector('#order-url').value;

// 	const postPath = `/order/?id=${id}`

// 	console.log({id, count, url});
// }

const sendNewPay = (container) => {

	const currentPrice = parseFloat(container.querySelector('.order-service-current-price').textContent);

	if (currentPrice < 1) {
		alert('Сумма пополнения может быть не менее 1 руб.');
		return;
	}

	const id = container.querySelector('#order-id').value;
	const count = container.querySelector('#order-count').value;
	const url = container.querySelector('#order-url').value;

	if (id?.length > 0 && count?.length > 0 && url?.length) {

		const form = document.createElement('form');
		form.action = `/order/?id=${id}`
		form.method = 'POST';

		const idInput = document.createElement('input');
		idInput.type = 'hidden';
		idInput.name = 'method_id';
		idInput.value = id;

		const countInput = document.createElement('input');
		countInput.type = 'hidden';
		countInput.name = 'count';
		countInput.value = count;

		const urlInput = document.createElement('input');
		urlInput.type = 'hidden';
		urlInput.name = 'url';
		urlInput.value = url;

		const preOrderInput = document.createElement('input');
		preOrderInput.type = 'hidden';
		preOrderInput.name = 'mode';
		preOrderInput.value = 'pre-order';

		const radioButtons = container.querySelectorAll('input[name="payment"]');
		const selectedOption = Array.from(radioButtons).find(radioButton => radioButton.checked);

		let payment = selectedOption.value;

		if (!selectedOption) {
			alert('Необходимо выбрать вариант оплаты');
			return;
		}

		const paymentInput = document.createElement('input');
		paymentInput.type = 'hidden';
		paymentInput.name = 'payment';
		paymentInput.value = payment;

		form.appendChild(idInput);
		form.appendChild(countInput);
		form.appendChild(urlInput);
		form.appendChild(preOrderInput);
		form.appendChild(paymentInput);

		document.body.appendChild(form);
		form.submit();
	} else {
		alert('Необходимо указать url и количество');
	}
};


const sendPayByBalance = (container) => {
	const id = container.querySelector('#order-id').value;
	const count = container.querySelector('#order-count').value;
	const url = container.querySelector('#order-url').value;

	if (id?.length > 0 && count?.length > 0 && url?.length) {

		// $_REQUEST["id"]
		// $_REQUEST["count"]
		// $_REQUEST["url"]

		const form = document.createElement('form');
		form.action = `/order/?id=${id}`
		form.method = 'POST';

		const idInput = document.createElement('input');
		idInput.type = 'hidden';
		idInput.name = 'id';
		idInput.value = id;

		const serviceInput = document.createElement('input');
		serviceInput.type = 'hidden';
		serviceInput.name = 'service_code';
		serviceInput.value = window.serviceCode;

		const countInput = document.createElement('input');
		countInput.type = 'hidden';
		countInput.name = 'count';
		countInput.value = count;

		const urlInput = document.createElement('input');
		urlInput.type = 'hidden';
		urlInput.name = 'url';
		urlInput.value = url;

		form.appendChild(idInput);
		form.appendChild(serviceInput);
		form.appendChild(countInput);
		form.appendChild(urlInput);

		document.body.appendChild(form);
		form.submit();
	} else {
		alert('Необходимо указать url и количество');
	}
};

document.addEventListener("DOMContentLoaded", function() {

	const servicesContainer = document.getElementById("services-items");

	if (!servicesContainer) return;

	servicesContainer.addEventListener("click", function(event) {

		const changeStep = 100;

		const {target} = event;
		const {classList} = target;

		const serviceElement = target.closest(".service");
		const serviceOrder = target.closest(".service-order");

		if (classList.contains("order-service-init"))
			renderOrderBlock(servicesContainer, serviceElement.dataset);

		if (classList.contains("order-service-select-pay"))
			renderPayBlock(servicesContainer, serviceOrder.dataset);

		else if (classList.contains("count-minus"))
			changeOrderCount(serviceOrder, -changeStep);

		else if (classList.contains("count-plus"))
			changeOrderCount(serviceOrder, changeStep);

		else if (classList.contains("order-service-pay-by-balance"))
			sendPayByBalance(servicesContainer);

		else if (classList.contains("order-service-pay-new"))
			sendNewPay(servicesContainer);

	});

	servicesContainer.addEventListener("input", function(event) {

		const {target} = event;
		const {classList} = target;

		const serviceOrder = target.closest(".service-order");

		console.log('change');

		if (classList.contains("value-input"))
			calcOrderCost(serviceOrder);

	})










	const buttons = document.querySelectorAll('#services-list button');

	if (!buttons.length) return

	console.log('init')

	// const titleElement = document.querySelector('#service-title');
	const itemsElement = document.querySelector('#services-items');
	const filtersListElement = document.querySelector('#services-filters-list');

	const renderList = (data) => {
		console.log({data});
		if (data.length > 0) {
			itemsElement.innerHTML = '';
			data.forEach(item => {
				itemsElement.insertAdjacentHTML('beforeend', getServiceItemHtml({ ...item, code: window.serviceCode }));
				// const listItem = document.createElement('li');
				// listItem.innerHTML = getServiceItemHtml({ ...item, code: window.serviceCode });
				// itemsElement.appendChild(listItem);
			});
		} else {
			itemsElement.innerHTML = '<span>По данному запросу ничего не найдено.</span>';
		}
	};

	const updateFilters = (serviceId) => {
		fetch(`/wp-json/gridsmm/v1/services/?serviceId=${serviceId}`)
			.then(response => response.json())
			.then(data => {
				const parsedData = JSON.parse(data);
				const uniqueNames = [...new Set(parsedData.map(item => item.name))];

				filtersListElement.innerHTML = '';
				uniqueNames.forEach(name => {
					const filterItem = document.createElement('li');
					filterItem.innerHTML = getFilterItemHtml({name});
					filtersListElement.appendChild(filterItem);
				});
				const filterButtons = filtersListElement.querySelectorAll('button');

				filterButtons.forEach(filterButton => {
					filterButton.addEventListener('click', () => {
						filterButtons.forEach(button => button.classList.remove('checked'));
				
						filterButton.classList.add('checked');
				
						const name = filterButton.getAttribute('data-name');
						fetch(`/wp-json/gridsmm/v1/services/?serviceId=${serviceId}&name=${name}`)
							.then(response => response.json())
							.then(parsedData => {
								renderList(JSON.parse(parsedData), window.serviceCode, name);
							})
							.catch(error => {
								console.error('Ошибка при выполнении GET-запроса с фильтром:', error);
							});
					});
				});
				
			})
			.catch(error => {
				console.error('Ошибка при выполнении GET-запроса для фильтров:', error);
			});
	};

	const executeInitialRequest = (initialServiceId) => {
		for (let i = 0; i < buttons.length; i++) {
			if (buttons[i].dataset.serviceId === initialServiceId) {
				const initialButton = buttons[i];
				const serviceId = initialButton.dataset.serviceId;
				const serviceName = initialButton.dataset.serviceName;
				window.serviceCode = initialButton.dataset.serviceCode;
				// titleElement.textContent = serviceName;
				itemsElement.innerHTML = '<div class="list-loader">Загрузка…</div>';

				fetch(`/wp-json/gridsmm/v1/services/?serviceId=${serviceId}`)
					.then(response => response.json())
					.then(data => {
						renderList(JSON.parse(data));
						updateFilters(serviceId);
					})
					.catch(error => {
						console.error('Ошибка при выполнении GET-запроса:', error);
					});
				break;
			}
		}
	};

	buttons.forEach(button => {
		button.addEventListener('click', () => {
			buttons.forEach(btn => btn.classList.remove('selected'));
			button.classList.add('selected');

			window.serviceCode = button.dataset.serviceCode;
			const serviceId = button.dataset.serviceId;
			const serviceName = button.dataset.serviceName;

			// titleElement.textContent = serviceName;
			// itemsElement.innerHTML = '<span>Загрузка…</span>';

			fetch(`/wp-json/gridsmm/v1/services/?serviceId=${serviceId}`)
				.then(response => response.json())
				.then(data => {
					renderList(JSON.parse(data));
					updateFilters(serviceId);
				})
				.catch(error => {
					console.error('Ошибка при выполнении GET-запроса:', error);
				});
		});
	});

	executeInitialRequest(window?.selectedService?.id || '1');
});



document.addEventListener("DOMContentLoaded", function() {

	// const balanceInput = document.querySelector("#user-balance-value");
	// if (!currentBalance.length) return;
	// const currentBalance = parseFloat(balanceInput.textContent) || 0;

	// const updateSubmitButton = () => {
	// 	const amountField = document.querySelector("#amount");
	// 	const form = amountField.closest("form");

	// 	if (form) {
	// 		const submitButton = form.querySelector('[type="submit"]');

	// 		if (submitButton) {
	// 				submitButton.classList.add("btn-highlight");
	// 		}
	// 	}
	// }

	// const updateUserBalanceValue = () => {
	// 	const currentDeposit = parseFloat(document.querySelector("#amount").value) || 0;
	// 	if (currentDeposit >= 0)
	// 		document.querySelector(".user-balance-value").textContent = (currentBalance + currentDeposit).toFixed(2);
	// }

	if (!document.querySelector("#balance-bonus")) return

	const updateBonus = () => {

		if (window?.bonusesList) {
			const bonuses = window?.bonusesList

			const balanceInput = document.querySelector("#amount");
			const currentBalance = parseFloat(balanceInput.value) || 0;
			let bonusValue = 0;
			let nextBonusAmount = 0;
			let nextBonusPercent = 0;

			for (const amount in bonuses) {
				if (currentBalance >= parseInt(amount)) {
					bonusValue = bonuses[amount];
				} else {
					nextBonusAmount = parseInt(amount) - currentBalance;
					nextBonusPercent = bonuses[amount];
					break;
				}
			}

			const bonusAmount = (currentBalance * bonusValue) / 100;

			document.querySelector("#balance-bonus").textContent = parseFloat(currentBalance + bonusAmount);
			document.querySelector("#bonus-amount").textContent = bonusAmount;
			document.querySelector("#bonus-percent").textContent = nextBonusPercent;
			document.querySelector("#bonus-cur-percent").textContent = bonusValue;

			const bonusMoreSection = document.querySelector("#bonus-more-section");
			const bonusMore = document.querySelector("#bonus-more");

			if (nextBonusAmount > 0) {
				bonusMoreSection.style.display = "block";
				bonusMore.textContent = nextBonusAmount;
			} else {
				bonusMoreSection.style.display = "none";
			}
		} else {
			setTimeout(() => {
				updateBonus();
			}, 2500);
		}
	}

	document.querySelector("#amount").addEventListener("input", updateBonus);
	document.querySelector("#amount").addEventListener("input", updateBonus);

	const fundsProposeElements = document.querySelectorAll(".funds-propose");

	if (fundsProposeElements.length > 0) {
		fundsProposeElements.forEach(function (element) {
			element.addEventListener("click", function () {
					const value = element.getAttribute("value");
					document.querySelector("#amount").value = value;
					updateBonus();

					// updateSubmitButton();
			});
		});
	}

	document.querySelector("#amount").addEventListener("input", function () {
		updateBonus();
		// updateUserBalanceValue();
		// updateSubmitButton();
	});

	updateBonus();




});

document.addEventListener("DOMContentLoaded", function() {

	const categoryElements = document.querySelectorAll(".catalog__category");
	const mainElement = document.querySelector(".catalog__main");

	function scrollToMainIfNecessary() {
		if (window.innerWidth < 1000) {
			mainElement.scrollIntoView({ behavior: "smooth" });
		}
	}

	categoryElements.forEach((category) => {
		category.addEventListener("click", scrollToMainIfNecessary);
	});

});


document.addEventListener("DOMContentLoaded", function() {

	const optionElements = document.querySelectorAll('.text-select__option');

	if (!optionElements.length) return;

	// const inputContainers = document.querySelectorAll('.text-select__input-container');
	// const options = document.querySelectorAll('.text-select__option');
	const inputElements = document.querySelectorAll('.text-select__input');

	optionElements.forEach(option => {
	option.addEventListener('click', function () {
			const dataValue = this.getAttribute('data-value');
			const dataName = this.getAttribute('data-name');
			const inputValueElement = document.querySelector(`.text-select__input-value[name="${dataName}-id"]`);
			const inputElement = document.querySelector('.text-select__input');

			const parent = this.closest('.text-select');
			parent.classList.remove('active');

			inputValueElement.value = dataValue;
			inputElement.value = this.textContent;
		});
	});

	inputElements.forEach((input) => {
	input.addEventListener('focus', () => {
		const parent = input.closest('.text-select');
		if (parent) {
			parent.classList.add('active');
		}
	});

	input.addEventListener('blur', () => {
		const parent = input.closest('.text-select');
		setTimeout(() => {
		
			if (parent) {
				parent.classList.remove('active');
			}
		}, 500);
	});
	});

});

document.addEventListener("DOMContentLoaded", function() {

	if (window.matchMedia("(max-width: 999px)").matches) {
		const elem = document.querySelector('.cards-container');
		if (!elem) return;

		const flkty = new Flickity( elem, {
			cellAlign: 'left',
			pageDots: false,
			autoPlay: 3500,
			// groupCells: '20%',
			// selectedAttraction: 0.03,
			// friction: 0.15
		});
		// flkty.select(3);
	}
});




document.addEventListener("DOMContentLoaded", function() {

	const inputsInUmField = document.querySelectorAll(".clear-um-crap input");

	inputsInUmField.forEach(input => {
		input.removeAttribute("placeholder");
	});

	document.addEventListener("click", function(event) {
		if (event.target.classList.contains("um-field")) {
			const inputElement = event.target.querySelector("input");
			if (inputElement) {
				inputElement.focus();
			}
		}
	});

	document.addEventListener("click", function(event) {
		if (event.target.classList.contains("um-field-error")) {
			 event.target.style.display = "none";
		}
	});


	const formFields = document.querySelectorAll(".um-form-field");

	formFields.forEach(formField => {


		if (formField.value) {
			
			const umField = formField.closest(".um-field");
			if (umField) {
				umField.classList.add("active");
			}
		}

		formField.addEventListener("focus", () => {
			const umField = formField.closest(".um-field");
			if (umField) {
				umField.classList.add("active");
			}
		});

		formField.addEventListener("blur", () => {
			if (formField.value.trim() === "") {
				const umField = formField.closest(".um-field");
				if (umField) {
					umField.classList.remove("active");
				}
			}
		});
	});
});
