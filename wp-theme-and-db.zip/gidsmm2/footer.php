		<footer class="fluid-container footer">
			<div class="footer__top">
				<div class="footer__brand">
					<div class="footer__brand-logo"><img class="site-logo" src="<? echo get_template_directory_uri() ?>/assets/images/logo-light.png"></div>
					<div class="footer__brand-note">Сервис раскрутки Instagram, Telegram и&nbsp;других площадок.</div>
				</div>
				<nav class="footer__nav">
					<ul>
					<li><a class="header__link" href="/catalog">
							<div>Каталог услуг</div></a></li>
					<li><a class="header__link" href="/reviews">
							<div>Отзывы</div></a></li>
					<li><a class="header__link" href="/help">
							<div>Помощь</div></a></li>
					<li><a class="header__link" href="/contacts">
							<div>Контакты</div></a></li>
					</ul>
				</nav>
			</div>
			<div class="footer__bottom">
				<div class="footer__legal-nav">
					<ul>
					<li><a href="/legal">Политика конфиденциальности</a></li>
					<li><a href="/offer">Публичная оферта</a></li>
					<li><a href="/cookies">Политика Cookies</a></li>
					<li>©2023</li>
					</ul>
				</div>
				<div class="footer__pay">
					<div class="footer__pay-title">Принимаем к оплате</div>
					<ul class="footer__pay-list">
					<li><img src="<? echo get_template_directory_uri() ?>/assets/images/payments/mastercard.svg" alt=""></li>
					<li><img src="<? echo get_template_directory_uri() ?>/assets/images/payments/visa.svg" alt=""></li>
					<li><img src="<? echo get_template_directory_uri() ?>/assets/images/payments/mir.svg" alt=""></li>
					<li><img src="<? echo get_template_directory_uri() ?>/assets/images/payments/qiwi.svg" alt=""></li>
					<li><img src="<? echo get_template_directory_uri() ?>/assets/images/payments/umoney.svg" alt=""></li>
					</ul>
				</div>
				<div class="footer__actions">
					<a class="btn btn_primary" href="/contacts">Написать в поддержку</a>
				</div>
			</div>
			<div class="footer__created">
				<a class="created" href="https://rusit-po.ru" target="_blank">
					<img class="created__img" src="/wp-content/themes/gidsmm2/assets/images/rusit-logo.svg" alt="Создание сайтов">
					<div class="created__link">Сайт разработан компанией Rusit</div>
				</a>
			</div>
		</footer>
		<div id="popups">
			<div class="popup" id="cookie" style="display:none">
				<div class="container">
					<div class="popup__text">Чтобы предоставить вам лучший сервис, мы используем файлы <b>cookie</b> и аналогичные методы. Файлы <b>cookie</b> используются для обеспечения правильной работы сайта.</div>
					<div class="popup__actions">
					<button class="btn btn_primary" id="cookie-ok">Принять</button>
					<button class="btn btn_squared btn_outline" id="cookie-close"><img src="<? echo get_template_directory_uri() ?>/assets/images/icons/x.svg"></button>
					</div>
				</div>
			</div>
		</div>
		<div id="burger-menu">
			<ul class="burger-nav">
				<li><a class="header__link" href="/catalog">
					<div>Каталог услуг</div></a></li>
				<li><a class="header__link" href="/reviews">
					<div>Отзывы</div></a></li>
				<li><a class="header__link" href="/help">
					<div>Помощь</div></a></li>
				<li><a class="header__link" href="/contacts">
					<div>Контакты</div></a></li>
			</ul>
			<div class="burger-actions">
				<div class="burger-actions__set">
					<?php if (is_user_logged_in()): ?>
						<a class="btn btn_light" href="/orders">Личный кабинет</a>
					<?php else: ?>
						<a class="btn btn_light" href="/register">Создать аккаунт</a>
						<a class="btn btn_glass btn_icon btn_login btn_icon_reverse" href="/login">Личный кабинет</a>
					<?php endif ?>
				</div>
				<div class="burger-actions__set">
					<?php if (is_user_logged_in()): ?>
						<div class="balance-detail balance-detail_compact balance-detail_light">
							<div class="balance-detail__main">
								<a class="btn btn_icon btn_rub" href="/orders">
									<div class="balance-label balance-label_light">
										<div class="balance-label__title">Ваш баланс:</div>
										<div class="balance-label__value"><?php require(__DIR__ . '/modules/user-balance.php'); ?></div>
									</div>
								</a>
							</div>
						</div>
					<?php endif ?>
				</div>
			</div>
			<footer class="burger-footer">
				<a class="btn btn_light btn_strange" href="/contacts">Написать в поддержку</a>
			</footer>
		</div>
	</div>
	<?php wp_footer(); ?>
</body>
</html>