<?php

///////////////////////////////////////////////////////////////
// Remove gigatons of default WP crap:

remove_action('wp_head', 'wp_generator');
remove_action('wp_head','wp_oembed_add_discovery_links', 10 );

// add_filter('rest_enabled', '__return_false');
add_filter('rest_jsonp_enabled', '__return_false');

remove_action('wp_head', 'rsd_link');

add_action( 'wp_enqueue_scripts', 'mywptheme_child_deregister_styles', 20 );
function mywptheme_child_deregister_styles() {
	wp_dequeue_style( 'classic-theme-styles' );
}

function disable_emoji_feature() {
	// Prevent Emoji from loading on the front-end
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );

	// Remove from admin area also
	remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
	remove_action( 'admin_print_styles', 'print_emoji_styles' );

	// Remove from RSS feeds also
	remove_filter( 'the_content_feed', 'wp_staticize_emoji');
	remove_filter( 'comment_text_rss', 'wp_staticize_emoji');

	// Remove from Embeds
	remove_filter( 'embed_head', 'print_emoji_detection_script' );

	// Remove from emails
	remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );

	// Disable from TinyMCE editor. Currently disabled in block editor by default
	add_filter( 'tiny_mce_plugins', 'disable_emojis_tinymce' );

	/** Finally, prevent character conversion too
		** without this, emojis still work 
		** if it is available on the user's device
	*/
	add_filter( 'option_use_smilies', '__return_false' );

}

function disable_emojis_tinymce( $plugins ) {
	if( is_array($plugins) ) {
		$plugins = array_diff( $plugins, array( 'wpemoji' ) );
	}
	return $plugins;
}

//

add_action('init', 'disable_emoji_feature');

remove_action( 'wp_enqueue_scripts', 'wp_enqueue_global_styles' );
remove_action( 'wp_footer', 'wp_enqueue_global_styles', 1 );

function wps_deregister_styles() {
	wp_dequeue_style( 'global-styles' );
}
add_action( 'wp_enqueue_scripts', 'wps_deregister_styles', 100 );

add_action( 'wp_enqueue_scripts', 'remove_global_styles' );
function remove_global_styles(){
	wp_dequeue_style( 'global-styles' );
}

//Remove Gutenberg Block Library CSS from loading on the frontend
function smartwp_remove_wp_block_library_css(){
	wp_dequeue_style( 'wp-block-library' );
	wp_dequeue_style( 'wp-block-library-theme' );
	wp_dequeue_style( 'wc-blocks-style' ); // Remove WooCommerce block CSS
}
add_action( 'wp_enqueue_scripts', 'smartwp_remove_wp_block_library_css', 100 );

//

remove_action( 'wp_head', 'rest_output_link_wp_head');
remove_action( 'wp_head', 'wp_oembed_add_discovery_links');
remove_action( 'template_redirect', 'rest_output_link_header', 11 );

//

function ikva_remove_robots_meta() {
	return null;
}

add_filter('wpseo_robots', 'ikva_remove_robots_meta');
add_filter('wpseo_googlebot', 'ikva_remove_robots_meta');
add_filter('wpseo_bingbot', 'ikva_remove_robots_meta');
add_filter( 'wpseo_canonical', '__return_false');
remove_filter('wp_robots', 'wp_robots_max_image_preview_large');

//

add_filter('after_setup_theme', 'remove_redundant_shortlink');

function remove_redundant_shortlink() {
	// remove HTML meta tag
	// <link rel='shortlink' href='http://example.com/?p=25' />
	remove_action('wp_head', 'wp_shortlink_wp_head', 10);

	// remove HTTP header
	// Link: <https://example.com/?p=25>; rel=shortlink
	remove_action( 'template_redirect', 'wp_shortlink_header', 11);
}
