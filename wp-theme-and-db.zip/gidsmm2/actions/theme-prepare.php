<?php


add_action('after_setup_theme', 'gridsmm_setup');

function gridsmm_setup() {
	load_theme_textdomain('gridsmm', get_template_directory() . '/languages');
	add_theme_support('title-tag');

	register_nav_menus(array('main-menu' => esc_html__('Main Menu', 'gridsmm')));
	register_nav_menus(array('auth-menu' => esc_html__('Auth Menu', 'gridsmm')));
}

function js_path($subpath) {
	return (get_template_directory_uri() . '\/js/' . $subpath);
}

function gridsmm_enqueue() {
	wp_enqueue_style('gridsmm-style', get_stylesheet_uri());
	wp_enqueue_style('gridsmm-main', get_template_directory_uri() . '/css/main.css');
	wp_enqueue_style('gridsmm-main', get_template_directory_uri() . '/css/flickity.css');

	wp_enqueue_script('flickity', js_path('flickity-2.3.0/flickity.pkgd.min.js'), array(), '2.3.0', true);
	wp_enqueue_script('micromodal', js_path('micromodal.min.js'), array(), '1.0', true);
	wp_enqueue_script('gridsmm-scripts', js_path('scripts.js'), array('jquery'), '1.0', true);

}

add_action('wp_enqueue_scripts', 'gridsmm_enqueue');


// add_filter('nav_menu_link_attributes', 'gridsmm_schema_url', 10);
// function gridsmm_schema_url($atts) {
// 	$atts['itemprop'] = 'url';
// 	return $atts;
// }

if (!function_exists('gridsmm_wp_body_open')) {
	function gridsmm_wp_body_open()
	{
		do_action('wp_body_open');
	}
}

//
add_theme_support('admin-bar', array('callback' => '__return_false'));

//
add_action('wp', 'add_my_cron_event');
add_action('my_daily_event', 'updateServices');

function add_my_cron_event()
{
	if (!wp_next_scheduled('my_daily_event')) {
		wp_schedule_event(time(), 'daily', 'my_daily_event');
	}
}

function updateServices()
{
	require_once "update.php";

	update();
}

//
add_action('rest_api_init', function () {
	register_rest_route('gridsmm/v1', '/services/', [
		 'methods' => 'GET',
		 'callback' => 'getServices',
		 'permission_callback' => '__return_true'
	]);
	register_rest_route('gridsmm/v1', '/payments/', [
		 'methods' => 'GET',
		 'callback' => 'get_payment_methods',
		 'permission_callback' => '__return_true'
	]);
	register_rest_route('gridsmm/v1', '/callback/onepayments/', [
		 'methods' => 'POST',
		 'callback' => 'callback_onepayments',
		 'permission_callback' => '__return_true'
	]);
	register_rest_route('gridsmm/v1', '/callback/lava/', [
		 'methods' => 'POST',
		 'callback' => 'callback_lava',
		 'permission_callback' => '__return_true'
	]);
});


function getServices(WP_REST_Request $request) {
	global $wpdb;

	$filter = "1";
	$filters = [];
	if (isset($request["serviceId"])) {
		$filter .= " AND serviceId = %d";
		$filters[] = $request["serviceId"];
	}
	if (isset($request["name"])) {
		$filter .= " AND name = %s";
		$filters[] = $request["name"];
	}
	$result = $wpdb->get_results($wpdb->prepare(
		"SELECT * FROM " . $wpdb->prefix . "services_methods WHERE " . $filter,
		$filters
	), ARRAY_A);

	return json_encode($result);
}

function generateBreadcrumbs($crumbs) {
	$html = '<div class="mini-hero__label"><a href="/">Главная</a> / ';

	foreach ($crumbs as $crumb) {
		if (isset($crumb['link'])) {
			$html .= '<a href="' . $crumb['link'] . '">' . $crumb['title'] . '</a>';
		} else {
			$html .= $crumb['title'];
		}

		$html .= ' / ';
	}

	$html = rtrim($html, ' / ');
	$html .= '</div>';

	return $html;
}
// function custom_breadcrumbs() {
//     // Получаем текущую страницу
//     $post = get_queried_object();

//     // Создаем массив для хранения хлебных крошек
//     $breadcrumbs = array();

//     // Добавляем ссылку на главную страницу
//     $breadcrumbs[] = '<a href="' . home_url() . '">Главная</a>';

//     // Получаем иерархию родительских страниц
//     $ancestors = get_post_ancestors($post);

//     // Идем вверх по иерархии и добавляем родительские страницы
//     foreach (array_reverse($ancestors) as $ancestor) {
//         $breadcrumbs[] = '<a href="' . get_permalink($ancestor) . '">' . get_the_title($ancestor) . '</a>';
//     }

//     // Если это страница записи, добавляем ее
//     if (is_single()) {
//         $breadcrumbs[] = '<a href="' . get_permalink() . '">' . get_the_title() . '</a>';
//     }

//     // Выводим хлебные крошки
//     echo '<div class="mini-hero__label">' . implode(' / ', $breadcrumbs) . '</div>';
//     echo '<br>';
//     global $post;
//     $ancestors = get_post_ancestors($post);

//     // Если есть родительские страницы, включаем их в список
//     if (!empty($ancestors)) {
//         $ancestors = array_reverse($ancestors);
//         foreach ($ancestors as $ancestor) {
//             echo '<a href="' . get_permalink($ancestor) . '">' . get_the_title($ancestor) . '</a> / ';
//         }
//     }

//     // Выводим текущую страницу
//     echo '<a href="' . get_permalink() . '">' . get_the_title() . '</a>';

// }

function render_pagination($total_posts, $posts_per_page, $current_page) {
	$total_pages = ceil($total_posts / $posts_per_page);

	// Проверка, есть ли более одной страницы
	if ($total_pages > 1) {
		echo '<div class="paginator"><div>';

		// Кнопка "Предыдущая"
		if ($current_page > 1) {
			echo '<a class="paginator__prev" href="' . get_pagenum_link($current_page - 1) . '"></a>';
		}

		echo '</div>';
		echo '<ul class="paginator__numbers">';

		// Генерация номеров страниц
		for ($i = 1; $i <= $total_pages; $i++) {
			$class = ($i === $current_page) ? 'selected' : '';
			echo '<li><a class="' . $class . '" href="' . get_pagenum_link($i) . '">' . $i . '</a></li>';
		}

		echo '</ul>';
		echo '<div>';

		// Кнопка "Следующая"
		if ($current_page < $total_pages) {
			echo '<a class="paginator__next" href="' . get_pagenum_link($current_page + 1) . '"></a>';
		}

		echo '</div></div>';
	}
}


function get_pay_redirect_html($url) {
	echo <<<HTML
		<div class="block">
			<h1>Перенаправление на сайт платёжной системы</h1>
			<br>
			<p>Если перенаправление не произошло автоматически, нажмите на ссылку:</p>
			<div style="max-width:760px; line-height:1.25em; margin-top:.25em;">
				<small><a href="$url">$url</a></small>
			</div>
			<br>
			<script>
				window.location.href = '$url';
			</script>
		</div>
	HTML;

}