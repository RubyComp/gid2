<?php

function register_shortcodes() {
	$shortcodes = array(
		'hero_main_page',
		'advantages',
		'cards',
		'functions',
		'about',
		'catalog',
		'functions_light',
		'faq',

		'hero_catalog_page',
		'hero_reviews_page',
		'hero_help_page',
		'hero_contacts_page',

		'reviews',
		'account_orders',
		'account_deposit',
		'account_balance',

		'registration_start',
		'registration_end',
		'login_start',
		'login_end',
		'reset_start',
		'reset_end',
		'login',

		'order',
		'out',
		'account_aside',

	);

	foreach ($shortcodes as $item) {
		$shortcode = $item . '_block';
		$callback = $shortcode . '_shortcode';
		add_shortcode($shortcode, $callback);
	}
}

function get_block_path($name) {
	return (get_template_directory() . '/parts/' . $name . '.php');
}

function hero_main_page_block_shortcode() {
	ob_start();
	include_once( get_block_path('hero-main-page') );
	return ob_get_clean();
}

function advantages_block_shortcode() {
	ob_start();
	include_once( get_block_path('advantages') );
	return ob_get_clean();
}

function cards_block_shortcode() {
	ob_start();
	include_once( get_block_path('cards') );
	return ob_get_clean();
}

function functions_block_shortcode() {
	ob_start();
	include_once( get_block_path('functions') );
	return ob_get_clean();
}

function about_block_shortcode() {
	ob_start();
	include_once( get_block_path('about') );
	return ob_get_clean();
}

function catalog_block_shortcode() {
	ob_start();
	include_once( get_block_path('catalog') );
	return ob_get_clean();
}

function functions_light_block_shortcode() {
	ob_start();
	include_once( get_block_path('functions-light') );
	return ob_get_clean();
}

function faq_block_shortcode() {
	ob_start();
	include_once( get_block_path('faq') );
	return ob_get_clean();
}


function hero_catalog_page_block_shortcode() {
	ob_start();
	include_once( get_block_path('hero-catalog-page') );
	return ob_get_clean();
}

function hero_reviews_page_block_shortcode() {
	ob_start();
	include_once( get_block_path('hero-reviews-page') );
	return ob_get_clean();
}

function hero_help_page_block_shortcode() {
	ob_start();
	include_once( get_block_path('hero-help-page') );
	return ob_get_clean();
}

function hero_contacts_page_block_shortcode() {
	ob_start();
	include_once( get_block_path('hero-contacts-page') );
	return ob_get_clean();
}


function reviews_block_shortcode() {
	ob_start();
	include_once( get_block_path('reviews') );
	return ob_get_clean();
}
function account_orders_block_shortcode() {
	ob_start();
	include_once( get_block_path('account-orders') );
	return ob_get_clean();
}

function account_deposit_block_shortcode() {
	ob_start();
	include_once( get_block_path('account-deposit') );
	return ob_get_clean();
}

function account_balance_block_shortcode() {
	ob_start();
	include_once( get_block_path('account-balance') );
	return ob_get_clean();
}
function registration_start_block_shortcode() {
	ob_start();
	include_once( get_block_path('registration-start') );
	return ob_get_clean();
}
function registration_end_block_shortcode() {
	ob_start();
	include_once( get_block_path('registration-end') );
	return ob_get_clean();
}
function login_start_block_shortcode() {
	ob_start();
	include_once( get_block_path('login-start') );
	return ob_get_clean();
}
function login_end_block_shortcode() {
	ob_start();
	include_once( get_block_path('login-end') );
	return ob_get_clean();
}
function reset_start_block_shortcode() {
	ob_start();
	include_once( get_block_path('reset-start') );
	return ob_get_clean();
}
function reset_end_block_shortcode() {
	ob_start();
	include_once( get_block_path('reset-end') );
	return ob_get_clean();
}
function login_block_shortcode() {
	ob_start();
	include_once( get_block_path('login') );
	return ob_get_clean();
}
function order_block_shortcode() {
	ob_start();
	include_once( get_block_path('order') );
	return ob_get_clean();
}
function out_block_shortcode() {
	ob_start();
	include_once( get_block_path('out') );
	return ob_get_clean();
}
function account_aside_block_shortcode() {
	ob_start();
	include_once( get_block_path('account-aside') );
	return ob_get_clean();
}


register_shortcodes();
