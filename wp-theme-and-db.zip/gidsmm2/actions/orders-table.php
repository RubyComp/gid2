<?php
require_once(ABSPATH . 'wp-admin/includes/class-wp-list-table.php');

function custom_orders_page() {
	add_menu_page('Заказы', 'Заказы', 'manage_options', 'custom-orders', 'custom_orders_page_callback');
}
add_action('admin_menu', 'custom_orders_page');

function custom_orders_page_callback() {
	?>
	<div class="wrap">
		<h1 class="wp-heading-inline">Заказы</h1>

		<?php
			$custom_orders_table = new Custom_Orders_Table();
			$custom_orders_table->prepare_items();
			$custom_orders_table->display();

			echo '<style>';
			echo '.column-url { width: 20%; }';
			echo '.column-id { width: 55px; }';
			echo '.column-user_id { width: 190px; }';
			echo '</style>';
		?>
		
	</div>
	<?php
}

class Custom_Orders_Table extends WP_List_Table {
	public function __construct() {
		parent::__construct(array(
			'singular' => 'order',
			'plural'   => 'orders',
			'ajax'     => false,
		));
	}

	public function column_user_id($item) {
		$user_data = get_userdata($item->user_id);
		if ($user_data) {
			$user_email = $user_data->user_email;
			$edit_link = admin_url("user-edit.php?user_id={$item->user_id}");
			return "<a href='{$edit_link}'>{$user_email}</a>";
		}
		return '<code>Пользователь не найден</code>';
	}

	public function get_columns() {
		return array(
			'id' => 'ID',
			'user_id' => 'Пользователь',
			// 'serviceId' => 'Service ID',
			'service_name' => 'Service Name',
			'apiId' => 'API ID',
			'orderId' => 'Order ID',
			'cost' => 'Cost',
			'count' => 'Count',
			'url' => 'URL',
			'name' => 'Name',
			'date' => 'Date',
		);
	}
	public function column_default($item, $column_name) {
		switch ($column_name) {
			case 'id':
			case 'serviceId':
			case 'service_name':
			case 'apiId':
			case 'orderId':
			case 'cost':
			case 'count':
			case 'url':
			case 'name':
			case 'date':
				return $item->$column_name;
			case 'user_id':
				return $this->column_user_id($item);
			default:
				return 'No data';
		}
	}

	public function prepare_items() {
		global $wpdb;

		$table_name = $wpdb->prefix . 'service_orders'; 
		$per_page = 15;

		$columns = $this->get_columns();
		$hidden = array();
		$sortable = $this->get_sortable_columns();

		$this->_column_headers = array($columns, $hidden, $sortable);

		$current_page = $this->get_pagenum();
		$total_items = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
		$total_pages = ceil($total_items / $per_page);

		$this->set_pagination_args(array(
			'total_items' => $total_items,
			'total_pages' => $total_pages,
			'per_page' => $per_page,
		));

		$orderby = (isset($_GET['orderby']) && in_array($_GET['orderby'], array_keys($sortable))) ? $_GET['orderby'] : 'id';
		$order = (isset($_GET['order']) && in_array($_GET['order'], array('asc', 'desc'))) ? $_GET['order'] : 'desc';

		$offset = ($current_page - 1) * $per_page;
		$query = $wpdb->prepare("
			SELECT so.*, ws.name as service_name
			FROM $table_name as so
			LEFT JOIN {$wpdb->prefix}services as ws
			ON so.serviceId = ws.id
			ORDER BY $orderby $order
			LIMIT $per_page
			OFFSET $offset
		");

		$this->items = $wpdb->get_results($query);
	}

	public function display() {
		parent::display();
	}
}
