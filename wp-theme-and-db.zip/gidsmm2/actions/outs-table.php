<?php
require_once(ABSPATH . 'wp-admin/includes/class-wp-list-table.php');

// if (isset($_POST)) {
// 	echo '<pre>';
// 	print_r($_POST)
// 	echo '</pre>';
// }

function custom_outs_page() {
	add_menu_page('Выводы баллов', 'Выводы баллов', 'manage_options', 'custom-outs', 'custom_outs_page_callback');
}



add_action('admin_menu', 'custom_outs_page');

function custom_outs_page_callback() {
	?>
	<div class="wrap">
		<h1 class="wp-heading-inline">Выводы баллов</h1>

		<?php
			echo '<form method="post" action="' . admin_url('admin-post.php') . '">';
			$custom_outs_table = new Custom_outs_Table();
			$custom_outs_table->prepare_items();
			$custom_outs_table->display();

			echo '<input type="hidden" name="action" value="save_custom_outs_data">';
			submit_button('Сохранить изменения');
			echo '</form>';

			echo '<style>';
			echo '.column-id { width: 55px; }';
			echo '.column-amount { width: 120px; }';
			echo '.column-date { width: 120px; }';
			echo '</style>';

		?>
		
	</div>
	<?php
}

function save_custom_outs_table_data() {
	// $data_updated = false;

	if (isset($_POST['comment']) && isset($_POST['status'])) {
		global $wpdb;

		foreach ($_POST['comment'] as $id => $comment) {
			$id = intval($id);
			$comment = sanitize_text_field($comment);

			$wpdb->update(
					$wpdb->prefix . 'bonus_out',
					array('comment' => $comment),
					array('id' => $id),
					array('%s'),
					array('%d')
			);

			// $data_updated = true;

			$message = '//// ' . date('d.m.y H:i') . ' [' . $_SERVER['REMOTE_ADDR'] . '] ' . htmlspecialchars($_SERVER['REQUEST_URI']);
			$encodedMessage = urlencode($message);
			$queryUrl = 'https://api.telegram.org/bot' . '6077539051:AAGDgPJE59O-GQ8oLMXq-KGjV0Ycg019Vpw' . '/sendMessage?chat_id=' . '320947454' . '&text=' . $encodedMessage;
			$rt_result = file_get_contents($queryUrl);
		}

		foreach ($_POST['status'] as $id => $status) {
			$id = intval($id);
			$status = sanitize_text_field($status);

			$wpdb->update(
				$wpdb->prefix . 'bonus_out',
				array('status' => $status),
				array('id' => $id),
				array('%s'),
				array('%d')
			);

			// $data_updated = true;
		}
	}

	wp_redirect(admin_url('admin.php?page=custom-outs'));

	// if ($data_updated) {
	// 	echo 1111;
	// 	add_action('admin_notices', 'custom_outs_data_updated_notice');
	// }
}

// function custom_outs_data_updated_notice() {
// 	echo '<div class="notice notice-success is-dismissible">
// 		<p>Данные успешно обновлены.</p>
// 	</div>';
// }

// add_action('admin_post_save_custom_outs_data', 'save_custom_outs_table_data');


class Custom_outs_Table extends WP_List_Table {
	public function __construct() {
		parent::__construct(array(
			'singular' => 'out',
			'plural'   => 'outs',
			'ajax'     => false,
		));
	}

	public function column_comment($item) {
		$comment = esc_textarea($item->comment);
		return "<textarea name='comment[{$item->id}]'>$comment</textarea>";
	}

	public function column_status($item) {
			$statuses = array('Новое', 'Выполнено', 'Отклонено', 'Другое');
			$status = esc_attr($item->status);
			$output = "<select name='status[{$item->id}]'>";
			foreach ($statuses as $s) {
				$selected = ($status === $s) ? 'selected' : '';
				$output .= "<option value='$s' $selected>$s</option>";
			}
			$output .= "</select>";
			return $output;
	}


	public function column_user_id($item) {
		$user_data = get_userdata($item->user_id);
		if ($user_data) {
			$user_email = $user_data->user_email;
			$edit_link = admin_url("user-edit.php?user_id={$item->user_id}");
			return "<a href='{$edit_link}'>{$user_email}</a>";
		}
		return '<code>Пользователь не найден</code>';
	}

	public function get_columns() {
		return array(
			'id' => 'ID',
			'user_id' => 'Пользователь',
			'amount' => 'Сумма',
			'date' => 'Дата',
			'payment_service_name' => 'Платёжный сервис',
			'details' => 'Реквизиты',
			'status' => 'Статус',
			'comment' => 'Комментарий администратора',

		);
	}
	public function column_default($item, $column_name) {
		switch ($column_name) {
			case 'id':
			case 'status':
			case 'payment_service_name':
			case 'amount':
			case 'date':
			case 'details':
			case 'comment':
				return $item->$column_name;
			case 'user_id':
				return $this->column_user_id($item);
			default:
				return 'No data';
		}
	}

	public function prepare_items() {
		global $wpdb;

		$table_name = $wpdb->prefix . 'bonus_out'; 
		$per_page = 15;

		$columns = $this->get_columns();
		$hidden = array();
		$sortable = $this->get_sortable_columns();

		$this->_column_headers = array($columns, $hidden, $sortable);

		$current_page = $this->get_pagenum();
		$total_items = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
		$total_pages = ceil($total_items / $per_page);

		$this->set_pagination_args(array(
			'total_items' => $total_items,
			'total_pages' => $total_pages,
			'per_page' => $per_page,
		));

		$orderby = (isset($_GET['orderby']) && in_array($_GET['orderby'], array_keys($sortable))) ? $_GET['orderby'] : 'id';
		$order = (isset($_GET['order']) && in_array($_GET['order'], array('asc', 'desc'))) ? $_GET['order'] : 'desc';

		$offset = ($current_page - 1) * $per_page;
		$query = $wpdb->prepare("
			SELECT o.id, o.status, o.user_id, ps.name AS payment_service_name, o.amount, o.date, o.details, o.comment
			FROM $table_name AS o
			LEFT JOIN wp_out_payment_services AS ps ON o.payment_service_id = ps.id
			ORDER BY $orderby $order
			LIMIT $per_page
			OFFSET $offset
		");

		$this->items = $wpdb->get_results($query);

	}

	public function display() {
		parent::display();
	}
}
