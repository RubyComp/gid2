<?php

require_once(__DIR__ . '/../modules/Api.php');

function update() {
	global $wpdb;

	$api = new Api();
	$services = $api->services();
	$services = json_decode(json_encode($services), true); // object to array
	
	// Get the service_rate_ratio from wp_options
	$service_rate_ratio = get_option('service_rate_ratio');
	
	if (!is_numeric($service_rate_ratio)) {
		// Handle the case when service_rate_ratio is not a valid number
		// You can return an error or set a default value.
		// For example:
		$service_rate_ratio = 1.2; // Default value
	}

	foreach ($services as $service) {
		// Multiply $service["rate"] by $service_rate_ratio
		$updated_rate = $service["rate"] * $service_rate_ratio;

		$wpdb->query($wpdb->prepare(
			"UPDATE " . $wpdb->prefix . "services_methods SET rate = %f, min = %d, max = %d, detail = %s WHERE apiId = %d",
			[$updated_rate, $service["min"], $service["max"], $service["name"], $service["service"]]
		));
	}
}
