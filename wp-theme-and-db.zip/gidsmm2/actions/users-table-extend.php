<?php

////

function get_deposit_orders_count($user_id) {
	global $wpdb;
	
	$table_name = $wpdb->prefix . 'deposit_orders';
	$user_id = intval($user_id);
	
	$query = $wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE user_id = %d", $user_id);
	
	$count = $wpdb->get_var($query);
	
	return $count;
}

function get_total_orders_amount($user_id) {
	global $wpdb;
	
	$table_name = $wpdb->prefix . 'wp_service_orders';
	$user_id = intval($user_id);
	
	$query = $wpdb->prepare("SELECT SUM(cost) FROM $table_name WHERE user_id = %d", $user_id);
	
	$total_amount = $wpdb->get_var($query);
	
	return $total_amount;
}

////

function balance_user_list_column($column) {
	$column['balance'] = 'Баланс (р)';
	return $column;
}
function orders_count_user_list_column($column) {
	$column['orders_count'] = 'Заказов';
	return $column;
}

////

function balance_user_list_column_content($value, $column_name, $user_id) {
	if ($column_name === 'balance') {
		$balance = get_user_balance($user_id);
		return $balance['value'];
	}
	return $value;
}

function orders_count_user_list_column_content($value, $column_name, $user_id) {
	if ($column_name === 'orders_count') {
		$count = get_deposit_orders_count($user_id);
		return $count;
	}
	return $value;
}

add_filter('manage_users_columns', 'balance_user_list_column');
add_filter('manage_users_columns', 'orders_count_user_list_column');

add_filter('manage_users_custom_column', 'balance_user_list_column_content', 10, 3);
add_filter('manage_users_custom_column', 'orders_count_user_list_column_content', 10, 3);

////

// function get_total_orders_amount($user_id) {
// 	global $wpdb;
	
// 	$table_name = $wpdb->prefix . 'wp_service_orders'; // Замените 'deposit_orders' на имя вашей таблицы
// 	$user_id = intval($user_id); // Обязательно проверьте и санитизируйте входные данные
	
// 	$query = $wpdb->prepare("SELECT SUM(cost) FROM $table_name WHERE user_id = %d", $user_id);
	
// 	$total_amount = $wpdb->get_var($query);
	
// 	return $total_amount;
// }

// function orders_total_user_list_column($column) {
// 	$column['orders_total'] = 'Сумма заказов';
// 	return $column;
// }
// add_filter('manage_users_columns', 'orders_total_user_list_column');

// function orders_total_user_list_column_content($value, $column_name, $user_id) {
// 	if ($column_name === 'orders_total') {
// 		$total = get_total_orders_amount($user_id);
// 		return $total;
// 	}
// 	return $value;
// }
// add_filter('manage_users_custom_column', 'orders_total_user_list_column_content', 10, 3);

////
