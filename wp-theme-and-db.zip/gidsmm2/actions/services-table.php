<?php
require_once(ABSPATH . 'wp-admin/includes/class-wp-list-table.php');
require_once(__DIR__ . '/update.php');

function custom_services_page() {
	add_menu_page('Сервисы', 'Сервисы', 'manage_options', 'custom-services', 'custom_services_page_callback');
}
add_action('admin_menu', 'custom_services_page');

// function telelog($text) {
// 	$message = $text . ' ' . time() . ' [' . $_SERVER['REMOTE_ADDR'] . '] ' . htmlspecialchars($_SERVER['REQUEST_URI']);
// 	$encodedMessage = urlencode($message);
// 	$queryUrl = 'https://api.telegram.org/bot' . '6077539051:AAGDgPJE59O-GQ8oLMXq-KGjV0Ycg019Vpw' . '/sendMessage?chat_id=' . '320947454' . '&text=' . $encodedMessage;
// 	$rt_result = file_get_contents($queryUrl);
// }
add_action('update_services', 'update_services');


function update_services() {
	// telelog('Was Updated');
	update();

}

function my_original_function() {
	// telelog('my_original_function');

	$timestamp = time() - 1;
	wp_schedule_single_event($timestamp, 'update_services');
}


function custom_admin_notice() {
	$message = 'Обновление запущено. Данные сервисов изменятся в ближайщее время.';
	return '<div class="notice notice-success is-dismissible"><p>' . esc_html($message) . '</p></div>';
}


function custom_services_page_callback() {

	$update_started = false;

	if (isset($_POST['update_service_rate_ratio'])) {
		$new_value = sanitize_text_field($_POST['service_rate_ratio']);
		update_option('service_rate_ratio', $new_value);
		my_original_function();
		$update_started = true;
	}

	// // Выводим список задач
	// echo '<script>console.log(';
	// echo(json_encode($cron_jobs));
	// echo ');</script>';


	$current_value = get_option('service_rate_ratio', '');

	?>
	<div class="wrap">
		<h1 class="wp-heading-inline">Сервисы</h1>

		<?php
			if ($update_started) {
				echo custom_admin_notice();
			}
		?>


		<form method="post" id="update-services">
			<label for="service_rate_ratio">Множитель цены:</label>
			<input type="text" name="service_rate_ratio" id="service_rate_ratio" value="<?php echo esc_attr($current_value); ?>">
			<input type="submit" name="update_service_rate_ratio" class="button button-primary" value="Обновить">
		</form>
		<p><small>При парсинге данных с удалённого сервера на сайте сохраняются оригинальные цены. Для их изменения следует использовать поле выше.<br>Например: Значение <code>1</code> будет означать, что цена будет такой же. А значение <code>1.5</code> увеичит цену на 50%.</small></p>

		<?php
			$custom_services_table = new Custom_services_Table();
			$custom_services_table->prepare_items();
			$custom_services_table->display();

			echo '<style>';
			echo '.column-id { width: 55px; }';
			echo '</style>';
		?>
	</div>
	<?php
}


class Custom_services_Table extends WP_List_Table {
	public function __construct() {
		parent::__construct(array(
			'singular' => 'services',
			'plural'   => 'services',
			'ajax'     => false,
		));
	}

	public function column_user_id($item) {
		$user_data = get_userdata($item->user_id);
		if ($user_data) {
			$user_email = $user_data->user_email;
			$edit_link = admin_url("user-edit.php?user_id={$item->user_id}");
			return "<a href='{$edit_link}'>{$user_email}</a>";
		}
		return '<code>Пользователь не найден</code>';
	}

	public function get_columns() {
		return array(
			'id' => 'id',
			'serviceName' => 'serviceName',
			'apiId' => 'apiId',
			'name' => 'name',
			'rate' => 'rate',
			'min' => 'min',
			'max' => 'max',
			'icon' => 'icon',
			'detail' => 'detail',
			'disc' => 'disc',
		);
	}

	public function column_default($item, $column_name) {
		switch ($column_name) {
			case 'id':
			case 'serviceName':
			case 'apiId':
			case 'name':
			case 'rate':
			case 'min':
			case 'max':
			case 'icon':
			case 'detail':
			case 'disc':
				return $item->$column_name;
			default:
				return 'No data';
		}
	}

	public function prepare_items() {
		global $wpdb;

		$table_name = $wpdb->prefix . 'services_methods'; 
		$per_page = 15;

		$columns = $this->get_columns();
		$hidden = array();
		$sortable = $this->get_sortable_columns();

		$this->_column_headers = array($columns, $hidden, $sortable);

		$current_page = $this->get_pagenum();
		$total_items = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
		$total_pages = ceil($total_items / $per_page);

		$this->set_pagination_args(array(
			'total_items' => $total_items,
			'total_pages' => $total_pages,
			'per_page' => $per_page,
		));

		$orderby = (isset($_GET['orderby']) && in_array($_GET['orderby'], array_keys($sortable))) ? $_GET['orderby'] : 'id';
		$order = (isset($_GET['order']) && in_array($_GET['order'], array('asc', 'desc'))) ? $_GET['order'] : 'desc';

		$offset = ($current_page - 1) * $per_page;
		$query = $wpdb->prepare("
			SELECT id, serviceId, apiId, name, rate, min, max, icon, detail, disc
			FROM $table_name
			ORDER BY $orderby $order
			LIMIT $per_page
			OFFSET $offset
		");

		$query = $wpdb->prepare("
			SELECT $table_name.id, 
				wp_services.name AS serviceName, 
				$table_name.apiId, 
				$table_name.name, 
				$table_name.rate, 
				$table_name.min, 
				$table_name.max, 
				$table_name.icon, 
				$table_name.detail, 
				$table_name.disc
			FROM $table_name
			LEFT JOIN wp_services 
			ON $table_name.serviceId = wp_services.id
			ORDER BY $table_name.$orderby $order
			LIMIT $per_page
			OFFSET $offset
		");


		$this->items = $wpdb->get_results($query);

	}

	public function display() {
		parent::display();
	}
}

?>