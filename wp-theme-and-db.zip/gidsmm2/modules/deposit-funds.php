<?php
function deposit_funds($user_id, $amount, $order_id, $service_id)
{
    global $wpdb;

    $wpdb->query('START TRANSACTION');

    try {

        $balance = $amount + get_user_balance($user_id)["value"];

        // 1. Обновление таблицы wp_deposit_orders
        $updateOrderQuery = $wpdb->prepare(
            "UPDATE {$wpdb->prefix}deposit_orders SET status = 'done' WHERE id = %d AND service_id = %d",
            $order_id,
            $service_id
        );
        $wpdb->query($updateOrderQuery);

        // 2. Обновление таблицы wp_user_balance
        $updateBalanceQuery = $wpdb->prepare(
            "UPDATE {$wpdb->prefix}user_balance SET balance =  %f WHERE user_id = %d",
            $balance,
            $user_id
        );
        $wpdb->query($updateBalanceQuery);

        $wpdb->query('COMMIT');
    } catch (Exception $e) {
        $wpdb->query('ROLLBACK');
        echo "Ошибка: " . $e->getMessage();
    }

    return $updateOrderQuery;
}

function undeposit_funds($user_id, $amount)
{
    global $wpdb;

    $wpdb->query('START TRANSACTION');

    try {

        $balance = get_user_balance($user_id)["value"] - $amount;

        // 2. Обновление таблицы wp_user_balance
        $updateBalanceQuery = $wpdb->prepare(
            "UPDATE {$wpdb->prefix}user_balance SET balance =  %f WHERE user_id = %d",
            $balance,
            $user_id
        );
        $wpdb->query($updateBalanceQuery);

        $wpdb->query('COMMIT');
    } catch (Exception $e) {
        $wpdb->query('ROLLBACK');
        echo "Ошибка: " . $e->getMessage();
    }

    return;
}

?>
