<?php
echo ('<span class="user-balance-value">' . get_current_user_balance()['value'] . '</span> <span>₽</span>');
echo ('<script>window.currentUser = {balance: ' . json_encode(get_current_user_balance()) .'}</script>');