<div class="account__aside">
	<div class="account-aside">
		<div class="balance">
		<div class="balance__body">
			<div class="balance__icon icon-rub"></div>
			<div class="balance__main">
				<div class="balance__title">Ваш баланс:</div>
				<div class="balance__value">
					<?php require(__DIR__ . '/../modules/user-balance.php'); ?>
				</div>
			</div>
		</div>
		<div class="balance__refill"><a class="btn btn_primary" href="/deposit">Пополнить баланс</a></div>
		</div>
		<ul class="account-nav">
		<li>
			<a class="account-nav__item" href="/orders">
				<div class="account-nav__icon icon-home"></div><span>Главная</span>
			</a>
		</li>
		<li>
			<a class="account-nav__item" href="/catalog">
				<div class="account-nav__icon icon-rocket"></div><span>Создать заказ</span>
			</a>
		</li>
		<li>
			<a class="account-nav__item" href="/balance">
				<div class="account-nav__icon icon-ruble"></div><span>Баланс</span>
			</a>
		</li>
		<li>
			<a class="account-nav__item" href="/account">
				<div class="account-nav__icon icon-settings"></div><span>Настройки</span>
			</a>
		</li>
		<li>
			<a class="account-nav__item" href="/help">
				<div class="account-nav__icon icon-help"></div><span>Помощь</span>
			</a>
		</li>
		<li>
			<a class="account-nav__item" href="/logout">
				<div class="account-nav__icon icon-exit"></div><span>Выйти</span>
			</a>
		</li>
		</ul>
		<div class="mini-feed">
		<div class="mini-feed__icon icon-fire"></div>
		<div class="mini-feed__title">Оцените нашу&nbsp;работу</div>
			<div class="mini-feed__actions">
				<a class="btn btn_light btn_action btn_up-next" href="/reviews">В отзывы</a>
			</div>
		</div>
	</div>
</div>