<?php
 

function get_bonuses_list() {
	return array(
		1000 => 3,
		5000 => 5,
		10000 => 10,
		50000 => 15,
		100000 => 20
	);;
}

function get_amount_with_bonus($initialAmount) {
	$bonusValue = 0;

	foreach ($bonuses_list as $amount => $percent) {
		if ($initialAmount >= $amount) {
			$bonusValue = $percent;
		}
	}

	$bonusAmount = ($initialAmount * $bonusValue) / 100;

	return $initialAmount + $bonusAmount;
}

function get_bonus_by_amount($initialAmount) {
	$bonusValue = 0;

	foreach ($bonuses_list as $amount => $percent) {
		if ($initialAmount >= $amount) {
			$bonusValue = $percent;
		}
	}

	$bonusAmount = ($initialAmount * $bonusValue) / 100;

	return $bonusAmount;
}


function deposit_bonuses($user_id, $points) {
	global $wpdb;

	$user = get_user_by('id', $user_id);

	if ($user) {
		$current_balance = $wpdb->get_var($wpdb->prepare("SELECT bonuses FROM wp_user_balance WHERE user_id = %d", $user_id));

		if ($current_balance !== null) {
			$new_balance = $current_balance + $points;

			$wpdb->update(
				'wp_user_balance',
				array('bonuses' => $new_balance),
				array('user_id' => $user_id),
				array('%d'),
				array('%d')
			);

			return true;
		} else {
			return false;
		}
	} else {
			return false;
	}
}
