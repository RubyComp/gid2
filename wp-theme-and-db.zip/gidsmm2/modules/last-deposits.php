<table class="table">
	<thead>
		<tr>
			<th>Сумма</th>
			<th>Валюта</th>
			<th>Статус</th>
			<!-- <th>Комментарий</th> -->
			<th>Дата</th>
		</tr>
	</thead>
	<tbody>

		<?php

			function get_status_desc($value) {

				switch ($value) {
					case 'done':
						return 'Платёж завершён';
						break;

					case 'new':
						return 'Создан';
						break;

					default:
						return '…';
						break;
				}

			}

			$current_user_id = get_current_user_id();

			if ($current_user_id) {
				global $wpdb;
				$table_name = $wpdb->prefix . 'deposit_orders';
				$query = $wpdb->prepare("SELECT amount, status, date FROM $table_name WHERE user_id = %d and `status` LIKE 'done' ORDER BY id DESC LIMIT 10", $current_user_id);

				$results = $wpdb->get_results($query);

				if (!empty($results)) {
					foreach ($results as $result) {
							
							$amount = $result->amount;
							$currency = 'рубль';
							$status = get_status_desc($result->status);
							$date = $result->date;

							echo <<<HTML
							<tr>
								<td>$amount</td>
								<td>$currency</td>
								<td>$status</td>
								<td>$date</td>
							</tr>
							HTML;
					}
				} else {
					echo '<tr><td colspan="4">Здесь будет отображаться история пополнений баланса.</td></tr>';
				}
			}
		?>

	</tbody>
</table>