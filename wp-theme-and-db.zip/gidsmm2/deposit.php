<?php

$process = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

	function get_user_id() {
		$current_user = wp_get_current_user();
		return $current_user->ID;
	}

    switch ($_POST["selected_payments"]){
        case "onepayments":
            require_once __DIR__ . "/payments/methods/onepayments.php";
            $payment = new onepayments();
            break;
        case "cardlink":
            require_once __DIR__ . "/payments/methods/cardlink.php";
            $payment = new cardlink();
            break;
        case "lava":
            require_once __DIR__ . "/payments/methods/lava.php";
            $payment = new lava();
            break;
        default:
            echo "ОШИБКА";
            return;
    }
    $process = $payment->process($_POST['amount'], get_user_id());
}

?>

<div class="block block-reviews">
	<div class="container">
		<?php if ($process !== null and $process["redirect"]): ?>
			<div class="title">Перенаправление на сайт платёжной системы</div>
			<p>Если перенаправление не произошло автоматически, нажмите на ссылку:</p>
			<div style="max-width:760px; line-height:1.25em;"><small><a href="<?php echo $process["url"]; ?>"><?php echo $process["url"]; ?></a></small></div>
			<script>
				window.location.href = '<?php echo $process["url"]; ?>';
			</script>
		<?php else: ?>
			<div>
				<a href="/dashboard"><small>< Вернуться в кабинет</small></a>
			</div>
			<div class="title">Пополнение баланса</div>
			<div class="mt-16">
				<form class="form max-w-[55rem] flex flex-col" method="POST">
					<div class="flex flex-col items-start gap-6">
                        <label for="fieldName" class="label">Выберите способ оплаты</label>
                        <select name="selected_payments">
                            <option value="onepayments">OnePayments</option>
                            <option value="cardlink">CardLink</option>
                            <option value="lava">Lava</option>
                        </select>
						<label for="fieldName" class="label">Сумма</label>
						<input class="field" id="amount" name="amount" type="number" step="1" min="1" placeholder="Введите сумму" required>
					</div>
					<br>
					<button class="btn btn-default" type="submit"><span>Пополнить</span></button>
					<br>
					<div>
						<p><strong>Режим тестового пополнения.</strong><br>Средства зачислются без оплаты.</p>
					</div>
				</form>
			</div>
		<?php endif; ?>
	</div>
</div>
