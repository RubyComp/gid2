<html lang="ru-RU">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
	<div id="wrapper">
		<header class="fluid-container header">
			<div class="header__content"><a class="header__logo" href="/"><img class="site-logo" src="<? echo get_template_directory_uri() ?>/assets/images/logo.png"></a>
				<nav class="header__nav">
					<ul>
						<li class="hover-container">
							<a class="header__link" href="/catalog">
								<div>Каталог услуг</div>
							</a>
							<div class="hover-block">
								<ul class="hover-list">

								<?php

									global $wpdb;
									global $selected_service_code;

									$table_name = $wpdb->prefix . 'services';
									$services = $wpdb->get_results("SELECT id, name, code FROM $table_name");

									function hover_item($id, $type, $text, $selected = false) {
										$css_classes = 'catalog__category';
										$img_path = get_template_directory_uri() . '/assets/images/social/' . $type . '.svg';
										$link = '/catalog/?service=' . $type;

										if ($selected) {
											$css_classes .= ' selected';
										}
										echo <<<HTML
											<li class="hover-item">
												<a href="$link">
													<div class="hover-item__icon">
														<img src="$img_path" alt="Телеграм">
													</div>
													<div class="hover-item__text">$text</div>
												</a>
											</li>
										HTML;
										// return '<button class="' . $css_classes . '" data-service-id="' . $id . '" data-service-code="' . $type . '" data-service-name="' . $type . '"><div class="catalog__category-icon"><img src="' . get_template_directory_uri() . '/assets/images/social/' . $type . '.svg" alt="Телеграм"></div><span>' . $text . '</span></button>';
									}
									if (!empty($services)) {
										// $is_first = true; ////


										foreach ($services as $service) {
											$is_selected_service = false;

											if ($selected_service_code && $selected_service_code == $service->code) {
												$is_selected_service = true;
											}

											echo hover_item($service->id, $service->code, $service->name, $is_selected_service);
											$is_first = false;
										}
									} else {
										echo 'Нет данных о сервисах.';
									}
									?>

								</ul>
							</div>
						</li>
						<li>
							<a class="header__link" href="/reviews">
								<div>Отзывы</div>
							</a>
						</li>
						<li>
							<a class="header__link" href="/help">
								<div>Помощь</div>
							</a>
						</li>
						<li>
							<a class="header__link" href="/contacts">
								<div>Контакты</div>
							</a>
						</li>
					</ul>
				</nav>
				<div class="header__actions">

					<?php if (is_user_logged_in()): ?>

						<a class="btn btn_icon btn_rub" href="/balance">
							<div class="balance-label">
								<div class="balance-label__title">Ваш баланс:</div>
								<div class="balance-label__value">
									<?php require(__DIR__ . '/modules/user-balance.php'); ?>
								</div>
							</div>
						</a>
						<a class="btn btn_primary" href="/orders">Личный кабинет</a>
					<?php else: ?>
						<a class="btn btn_icon btn_login" href="/balance">
							<span>Личный кабинет</span>
						</a>
						<a class="btn btn_primary" href="/register">Создать аккаунт</a>
					<?php endif; ?>
				</div>
			</div>
			<div class="header__burger">
				<div id="burger"><i></i><i></i><i></i></div>
			</div>
		</header>